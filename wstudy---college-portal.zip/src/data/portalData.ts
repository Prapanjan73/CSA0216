import {
  StudentProfile,
  AcademicCoreProgress,
  CourseSlot,
  TimetableDay,
  PortalNotice,
  DueListItem,
  WalletTransaction,
  TranscriptCourse
} from '../types';

export const initialStudentProfile: StudentProfile = {
  name: 'Aarav Sharma',
  registerNumber: '211425104088',
  degree: 'B.Tech',
  department: 'Computer Science and Engineering',
  cgpa: 8.67,
  creditsEarned: 12,
  totalCredits: 192,
  statusBadge: 'Excelling',
  happiness: 20,
  punctuality: 90,
  assignmentsCount: '-',
  missedTasks: 0,
  avatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=400&h=400&q=80',
  socialLinks: {
    github: 'https://github.com/aarav-sharma-dev',
    linkedin: 'https://linkedin.com/in/aarav-sharma-cs',
    portfolio: 'https://aaravsharma.dev',
    leetcode: 'https://leetcode.com/aarav_codes'
  }
};

export const academicProgressList: AcademicCoreProgress[] = [
  {
    title: 'University Core',
    completed: 1,
    total: 10,
    cgpa: '8.00',
    color: '#8b5cf6'
  },
  {
    title: 'University Elective',
    completed: 0,
    total: 2,
    cgpa: '-',
    color: '#06b6d4'
  },
  {
    title: 'Program Core',
    completed: 2,
    total: 27,
    cgpa: '9.00',
    color: '#d946ef'
  },
  {
    title: 'Program Elective',
    completed: 0,
    total: 6,
    cgpa: '-',
    color: '#f43f5e'
  }
];

// Exact Course Attendance Logs for CSA0216 matching video at 00:15 - 00:19
const cProgrammingLogs = [
  { sNo: 1, date: '30 Oct 2026', session: 2, status: 'Present' as const },
  { sNo: 2, date: '30 Oct 2026', session: 1, status: 'Present' as const },
  { sNo: 3, date: '28 Oct 2026', session: 2, status: 'Present' as const },
  { sNo: 4, date: '28 Oct 2026', session: 1, status: 'Present' as const },
  { sNo: 5, date: '26 Oct 2026', session: 2, status: 'Present' as const },
  { sNo: 6, date: '26 Oct 2026', session: 1, status: 'Present' as const },
  { sNo: 7, date: '23 Oct 2026', session: 2, status: 'Present' as const },
  { sNo: 8, date: '23 Oct 2026', session: 1, status: 'Present' as const },
  { sNo: 9, date: '21 Oct 2026', session: 2, status: 'Present' as const },
  { sNo: 10, date: '21 Oct 2026', session: 1, status: 'Present' as const },
  { sNo: 11, date: '16 Oct 2026', session: 2, status: 'Absent' as const },
  { sNo: 12, date: '16 Oct 2026', session: 1, status: 'Absent' as const },
  { sNo: 13, date: '14 Oct 2026', session: 2, status: 'Present' as const },
  { sNo: 14, date: '14 Oct 2026', session: 1, status: 'Present' as const },
  { sNo: 15, date: '12 Oct 2026', session: 2, status: 'Present' as const },
  { sNo: 16, date: '12 Oct 2026', session: 1, status: 'Present' as const },
  { sNo: 17, date: '09 Oct 2026', session: 2, status: 'Present' as const },
  { sNo: 18, date: '09 Oct 2026', session: 1, status: 'Present' as const },
  { sNo: 19, date: '07 Oct 2026', session: 2, status: 'Present' as const },
  { sNo: 20, date: '07 Oct 2026', session: 1, status: 'Present' as const },
  { sNo: 21, date: '05 Oct 2026', session: 2, status: 'Absent' as const },
  { sNo: 22, date: '05 Oct 2026', session: 1, status: 'Absent' as const },
  { sNo: 23, date: '30 Sept 2026', session: 2, status: 'Present' as const },
  { sNo: 24, date: '30 Sept 2026', session: 1, status: 'Present' as const },
  { sNo: 25, date: '28 Sept 2026', session: 1, status: 'Present' as const }
];

export const courseSlotsData: CourseSlot[] = [
  {
    slot: 'SLOT A',
    code: 'CSA0216',
    title: 'C PROGRAMMING',
    percentage: 84,
    color: '#22c55e',
    credits: 4,
    faculty: 'Dr. Marcus Vance',
    venue: 'Academic Block 4, Lab 204',
    attendedClasses: 21,
    totalClasses: 25,
    category: 'Program Core',
    goals: [
      '1. To familiarize the basic concepts of computer programming.',
      '2. To provide knowledge on syntax and semantics of "C" language.',
      '3. To learn how to write modular and readable C Programs.',
      '4. To write programs using structured programming approach to solve problems.',
      '5. To provide training in writing efficient, maintainable and portable code.'
    ],
    outcomes: [
      { code: 'CO1', desc: 'Construct structured C programs using constants, variables, data types, and preprocessor directives to address basic problems.' },
      { code: 'CO2', desc: 'Examine and write solutions for problems using operators, decision-making, and looping constructs.' },
      { code: 'CO3', desc: 'Solve problems for searching, sorting, and merging using array and string processing techniques.' },
      { code: 'CO4', desc: 'Implement structures, unions, and nested structures for modeling and processing real-world data.' },
      { code: 'CO5', desc: 'Design modular and scalable C programs using functions, recursion, pointers, and file handling.' }
    ],
    coPoMapping: [
      { co: 'CO1', po: [3, 2, 2, '-', '-', 1] },
      { co: 'CO2', po: [3, 3, 2, '-', '-', 1] },
      { co: 'CO3', po: [3, 3, 3, 2, '-', 2] },
      { co: 'CO4', po: [3, 3, 2, 2, '-', 2] },
      { co: 'CO5', po: [3, 3, 3, 2, 2, 2] }
    ],
    attendanceLogs: cProgrammingLogs
  },
  {
    slot: 'SLOT B',
    code: 'BTA0105',
    title: 'BIOLOGY AND ENVIRONMENTAL SCIENCE FOR ENGINEERS',
    percentage: 80,
    color: '#22c55e',
    credits: 3,
    faculty: 'Dr. Elena Rostova',
    venue: 'SCAD Building, Hall 102',
    attendedClasses: 20,
    totalClasses: 25,
    category: 'University Core',
    goals: [
      '1. To provide knowledge to students with strong fundamentals and clear understanding of the principles of Bioinspiration and biomimetics.',
      '2. To gain knowledge for the development of biosensors.',
      '3. To gain knowledge about the cell constituents and study different organ systems.',
      '4. To impart knowledge on ecology, solid waste management and environmental implications.',
      '5. To groom students to know the importance of renewable energy and various types of pollution.'
    ],
    outcomes: [
      { code: 'CO1', desc: 'Understand fundamental concepts of biomolecules and cell mechanics.' },
      { code: 'CO2', desc: 'Comprehend the biological sensory organs and their synthetic analogues.' },
      { code: 'CO3', desc: 'Analyze environmental protection frameworks and renewable energy sources.' }
    ],
    attendanceLogs: [
      { sNo: 1, date: '30 Oct 2026', session: 1, status: 'Present' },
      { sNo: 2, date: '28 Oct 2026', session: 1, status: 'Present' },
      { sNo: 3, date: '26 Oct 2026', session: 1, status: 'Absent' },
      { sNo: 4, date: '23 Oct 2026', session: 1, status: 'Present' }
    ]
  },
  {
    slot: 'SLOT C',
    code: 'EEA0115',
    title: 'BASIC ELECTRICAL AND ELECTRONICS ENGINEERING',
    percentage: 93,
    color: '#22c55e',
    credits: 4,
    faculty: 'Prof. Julian Sterling',
    venue: 'Engineering Block 2, Lab E-11',
    attendedClasses: 28,
    totalClasses: 30,
    category: 'University Core',
    goals: [
      '1. To understand DC circuits and theorems.',
      '2. To study AC circuits and magnetic circuits.',
      '3. To understand basic semiconductor devices and digital circuits.'
    ],
    outcomes: [
      { code: 'CO1', desc: 'Analyze electrical circuits using network theorems.' },
      { code: 'CO2', desc: 'Demonstrate working principles of transformers and induction machines.' }
    ],
    attendanceLogs: [
      { sNo: 1, date: '29 Oct 2026', session: 1, status: 'Present' },
      { sNo: 2, date: '27 Oct 2026', session: 1, status: 'Present' },
      { sNo: 3, date: '25 Oct 2026', session: 1, status: 'Present' }
    ]
  },
  {
    slot: 'SLOT D',
    code: 'UBA0603',
    title: 'APPLIED MATHEMATICS',
    percentage: 79,
    color: '#f97316',
    credits: 4,
    faculty: 'Dr. Sophia Martinez',
    venue: 'Auditorium Block, Hall 301',
    attendedClasses: 19,
    totalClasses: 24,
    category: 'Program Core',
    goals: [
      '1. To equip students with linear algebra and matrix decomposition concepts.',
      '2. To develop calculus of variations and transform techniques.'
    ],
    outcomes: [
      { code: 'CO1', desc: 'Solve system of linear equations using eigenvalues and eigenvectors.' },
      { code: 'CO2', desc: 'Apply numerical techniques to solve boundary value problems.' }
    ],
    attendanceLogs: [
      { sNo: 1, date: '29 Oct 2026', session: 1, status: 'Present' },
      { sNo: 2, date: '27 Oct 2026', session: 1, status: 'Absent' },
      { sNo: 3, date: '22 Oct 2026', session: 1, status: 'Present' }
    ]
  }
];

// All courses shown in left menu "My Courses" in the video at 00:27
export const allMyCoursesList = [
  { code: 'BTA0105', slot: 'SLOT B', name: 'BIOLOGY AND ENVIRONMENTAL SCIENCE FOR ENGINEERS', faculty: 'Dr. Elena Rostova' },
  { code: 'CSA0216', slot: 'SLOT A', name: 'C PROGRAMMING', faculty: 'Dr. Marcus Vance' },
  { code: 'EEA0115', slot: 'SLOT C', name: 'BASIC ELECTRICAL AND ELECTRONICS ENGINEERING', faculty: 'Prof. Julian Sterling' },
  { code: 'UBA0603', slot: 'SLOT D', name: 'APPLIED MATHEMATICS', faculty: 'Dr. Sophia Martinez' },
  { code: 'CSA0703', slot: 'SLOT B', name: 'COMPUTER NETWORKS', faculty: 'Prof. Alexander Reed' },
  { code: 'ECA4701', slot: 'SLOT A', name: 'PRINCIPLES OF DIGITAL SYSTEM DESIGN', faculty: 'Dr. Claire Bennett' },
  { code: 'UBA0405', slot: 'SLOT A', name: 'DISCRETE MATHEMATICS', faculty: 'Prof. Jonathan Cole' },
  { code: 'UBA2801', slot: 'SLOT C', name: 'PROFESSIONAL ETHICS AND LEGAL PRACTICES', faculty: 'Prof. Rachel Dawson' }
];

// Academic Transcript records matching video at 00:31
export const academicTranscriptData: TranscriptCourse[] = [
  {
    code: 'CSA0703',
    name: 'COMPUTER NETWORKS',
    credits: 4,
    type: 'Program Core',
    status: 'Completed',
    grade: 'S'
  },
  {
    code: 'UBA0405',
    name: 'DISCRETE MATHEMATICS',
    credits: 4,
    type: 'University Core',
    status: 'Completed',
    grade: 'A+'
  },
  {
    code: 'ECA4701',
    name: 'PRINCIPLES OF DIGITAL SYSTEM DESIGN',
    credits: 4,
    type: 'Program Core',
    status: 'Completed',
    grade: 'A'
  },
  {
    code: 'UBA2801',
    name: 'PROFESSIONAL ETHICS AND LEGAL PRACTICES',
    credits: 4,
    type: 'University Core',
    status: 'Failed Exam',
    grade: 'U'
  }
];

export const timetableMonthData: TimetableDay[] = [
  {
    dayName: 'SUN',
    dateNum: 1,
    fullDate: '2026-11-01',
    classes: []
  },
  {
    dayName: 'MON',
    dateNum: 2,
    fullDate: '2026-11-02',
    classes: [
      { code: 'CSA0216', slot: 'SLOT A', time: '08:00–11:00', colorVariant: 'blue', title: 'C PROGRAMMING', faculty: 'Dr. Marcus Vance', startHour: 8, durationHours: 3 },
      { code: 'BTA0105', slot: 'SLOT B', time: '12:00–15:00', colorVariant: 'red', title: 'BIOLOGY & ENV SCIENCE', faculty: 'Dr. Elena Rostova', startHour: 12, durationHours: 3 }
    ]
  },
  {
    dayName: 'TUE',
    dateNum: 3,
    fullDate: '2026-11-03',
    classes: [
      { code: 'EEA0115', slot: 'SLOT C', time: '08:00–11:00', colorVariant: 'green', title: 'BASIC ELECTRICAL', faculty: 'Prof. Julian Sterling', startHour: 8, durationHours: 3 },
      { code: 'UBA0603', slot: 'SLOT D', time: '12:00–15:00', colorVariant: 'amber', title: 'APPLIED MATHEMATICS', faculty: 'Dr. Sophia Martinez', startHour: 12, durationHours: 3 }
    ]
  },
  {
    dayName: 'WED',
    dateNum: 4,
    fullDate: '2026-11-04',
    classes: [
      { code: 'BTA0105', slot: 'SLOT B', time: '08:00–11:00', colorVariant: 'red', title: 'BIOLOGY & ENV SCIENCE', faculty: 'Dr. Elena Rostova', startHour: 8, durationHours: 3 },
      { code: 'CSA0216', slot: 'SLOT A', time: '12:00–15:00', colorVariant: 'blue', title: 'C PROGRAMMING', faculty: 'Dr. Marcus Vance', startHour: 12, durationHours: 3 }
    ]
  },
  {
    dayName: 'THU',
    dateNum: 5,
    fullDate: '2026-11-05',
    classes: [
      { code: 'UBA0603', slot: 'SLOT D', time: '08:00–11:00', colorVariant: 'amber', title: 'APPLIED MATHEMATICS', faculty: 'Dr. Sophia Martinez', startHour: 8, durationHours: 3 },
      { code: 'EEA0115', slot: 'SLOT C', time: '12:00–15:00', colorVariant: 'green', title: 'BASIC ELECTRICAL', faculty: 'Prof. Julian Sterling', startHour: 12, durationHours: 3 }
    ]
  },
  {
    dayName: 'FRI',
    dateNum: 6,
    fullDate: '2026-11-06',
    classes: [
      { code: 'CSA0216', slot: 'SLOT A', time: '08:00–11:00', colorVariant: 'blue', title: 'C PROGRAMMING', faculty: 'Dr. Marcus Vance', startHour: 8, durationHours: 3 },
      { code: 'BTA0105', slot: 'SLOT B', time: '12:00–15:00', colorVariant: 'red', title: 'BIOLOGY & ENV SCIENCE', faculty: 'Dr. Elena Rostova', startHour: 12, durationHours: 3 }
    ]
  },
  {
    dayName: 'SAT',
    dateNum: 7,
    fullDate: '2026-11-07',
    classes: []
  },
  {
    dayName: 'SUN',
    dateNum: 8,
    fullDate: '2026-11-08',
    classes: []
  },
  {
    dayName: 'MON',
    dateNum: 9,
    fullDate: '2026-11-09',
    classes: []
  },
  {
    dayName: 'TUE',
    dateNum: 10,
    fullDate: '2026-11-10',
    classes: []
  }
];

export const portalNoticesList: PortalNotice[] = [
  {
    id: 'n-1',
    title: 'Induction cum Freshers Eve',
    category: 'INSTITUTION',
    author: 'Dr. Adrian Vance',
    timestamp: 'Oct 9, 3:04 PM',
    audience: 'Everyone · WSTUDY - Engineering',
    attachmentName: 'WhatsApp Image 2026-10-09 at 13.20.15.jpeg',
    body: 'Warm welcome to all newly admitted engineering students! The formal Induction cum Freshers Eve "AURA 2026" will be held at the University Central Amphitheater on October 14th from 4:30 PM onwards. Formal dress code applies. Cultural performances, awards, and dinner are arranged.',
    isBookmarked: false
  },
  {
    id: 'n-2',
    title: 'Keep away from monkey capture cage',
    category: 'INSTITUTION',
    author: 'Dr. Adrian Vance',
    timestamp: 'Oct 8, 9:29 AM',
    audience: 'Everyone · WSTUDY - Engineering',
    body: 'The Forest Department has placed a monkey capture cage between the SCAD Building and the DG Room today.\n\nAs advised by the officials, students must avoid this area until the capture operation is completed. Faculty and staff are requested to ensure compliance and keep students away from the cage.\n\nYour cooperation is essential for everyone\'s safety.',
    isBookmarked: true
  },
  {
    id: 'n-3',
    title: 'Internal Assessment - 1 Schedule (Sep-Dec 2026)',
    category: 'ACADEMIC',
    author: 'Controller of Examinations',
    timestamp: 'Oct 6, 11:15 AM',
    audience: 'UG B.Tech All Batches',
    body: 'The First Continuous Internal Assessment (CIA-1) will commence from November 15, 2026. Students must ensure minimum 75% attendance in respective courses to be eligible to appear without condonation fees.',
    isBookmarked: false
  },
  {
    id: 'n-4',
    title: 'Symposium "TechFest 2026" Paper Submission Open',
    category: 'EVENTS',
    author: 'CSE Association Coordinator',
    timestamp: 'Oct 4, 2:00 PM',
    audience: 'Students & Faculty',
    body: 'Submissions for technical research tracks, AI Hackathons, and Robotics design challenge are officially open. Cash prizes worth ₹2,50,000 to be won. Early bird submission deadline: October 25, 2026.',
    isBookmarked: false
  },
  {
    id: 'n-5',
    title: 'Hostel Gate Pass Guidelines for Weekend Exit',
    category: 'INSTITUTION',
    author: 'Chief Hostel Warden',
    timestamp: 'Oct 2, 4:45 PM',
    audience: 'Hostel Residents Only',
    body: 'All hostellers planning weekend exit must submit digital gate pass request on WSTUDY portal at least 24 hours prior with parent SMS OTP verification.',
    isBookmarked: false
  },
  {
    id: 'n-6',
    title: 'Library Extended Hours for End-Sem Exam Prep',
    category: 'ACADEMIC',
    author: 'Chief Librarian',
    timestamp: 'Sep 29, 10:00 AM',
    audience: 'All Students',
    body: 'The Central Library reading hall will remain open 24/7 starting November 10th with high-speed WiFi and coffee vending station for examination preparation.',
    isBookmarked: false
  },
  {
    id: 'n-7',
    title: 'Bus Route #14 Schedule Diversion due to Metro Work',
    category: 'INSTITUTION',
    author: 'Transport Coordinator',
    timestamp: 'Sep 25, 8:30 AM',
    audience: 'Day Scholar Commuters',
    body: 'Please note Route 14 (Tambaram to Campus) will detour through Bypass Road for the next two weeks. Morning pickup times will be advanced by 10 minutes.',
    isBookmarked: false
  },
  {
    id: 'n-8',
    title: 'Placement Drive: Tier-1 Tech Registration',
    category: 'EVENTS',
    author: 'Career & Placement Cell',
    timestamp: 'Sep 20, 1:20 PM',
    audience: 'Final & Pre-Final Year UG',
    body: 'Eligible students with CGPA >= 7.50 and no standing arrears may submit their resume for Amazon, Google, and Microsoft campus recruitment round.',
    isBookmarked: false
  }
];

export const defaultDueItems: DueListItem[] = [
  {
    id: 'd-1',
    category: 'Tuition Fee (Semester 3)',
    description: 'B.Tech CSE Semester 3 Tuition Fee',
    amount: 125000,
    dueDate: '2026-11-20',
    status: 'Paid'
  },
  {
    id: 'd-2',
    category: 'Library Book Overdue',
    description: 'Introduction to Algorithms (Cormen) - Book ID #LIB-4402',
    amount: 150,
    dueDate: '2026-11-05',
    status: 'Pending'
  },
  {
    id: 'd-3',
    category: 'Special Lab Consumable Charge',
    description: 'Embedded Systems & IoT Hardware Kit',
    amount: 1800,
    dueDate: '2026-11-15',
    status: 'Pending'
  }
];

export const defaultWalletTransactions: WalletTransaction[] = [
  { id: 'w-1', type: 'Debit', title: 'Central Canteen - Lunch Meal', amount: 85, date: 'Today, 1:15 PM', wallet: 'Mess Wallet' },
  { id: 'w-2', type: 'Debit', title: 'Library Printout (12 pages B&W)', amount: 24, date: 'Yesterday, 4:20 PM', wallet: 'Print & Lab Credits' },
  { id: 'w-3', type: 'Credit', title: 'Monthly Allowance Top-up (UPI)', amount: 2000, date: 'Nov 1, 9:00 AM', wallet: 'Campus SmartCard' },
  { id: 'w-4', type: 'Debit', title: 'Stationery Store - Notebook & Pen', amount: 120, date: 'Oct 30, 11:10 AM', wallet: 'Campus SmartCard' }
];

export const defaultWallpapers = [
  {
    id: 'mountain-valley',
    name: 'Mountain Pine Valley (Default)',
    url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1600&q=80',
    fallbackLocal: '/assets/aistudio/WhatsApp_Image_2026-11-01_at_11.20.23_PM_9194c39d.jpeg'
  },
  {
    id: 'misty-forest',
    name: 'Misty Alpine Woods',
    url: 'https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1600&q=80'
  },
  {
    id: 'campus-modern',
    name: 'University Quad Architecture',
    url: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1600&q=80'
  },
  {
    id: 'cosmic-dark',
    name: 'Deep Space Nebula',
    url: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=1600&q=80'
  },
  {
    id: 'minimal-obsidian',
    name: 'Minimal Dark Obsidian',
    url: ''
  }
];
