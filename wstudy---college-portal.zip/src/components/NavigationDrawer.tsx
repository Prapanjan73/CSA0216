import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search,
  Cloud,
  Megaphone,
  GraduationCap,
  Bus,
  BookOpen,
  ChevronRight,
  ChevronDown,
  X,
  FileText,
  UserCheck,
  Building,
  CalendarCheck,
  Award,
  Layers
} from 'lucide-react';
import { ViewTab, StudentProfile } from '../types';
import { allMyCoursesList } from '../data/portalData';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: ViewTab, extra?: string) => void;
  onOpenWSpace: () => void;
  onOpenODModal: () => void;
  onOpenCourseEnrollment: () => void;
  onOpenDualProgram: () => void;
  onOpenHostelTransport: (type: 'transport' | 'hostel') => void;
  onSelectCourseByCode: (code: string) => void;
  student: StudentProfile;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onOpenWSpace,
  onOpenODModal,
  onOpenCourseEnrollment,
  onOpenDualProgram,
  onOpenHostelTransport,
  onSelectCourseByCode,
  student
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedSection, setExpandedSection] = useState<string | null>('learning');
  const [isMyCoursesExpanded, setIsMyCoursesExpanded] = useState(true);

  const toggleSection = (section: string) => {
    setExpandedSection(prev => (prev === section ? null : section));
  };

  const handleItemClick = (action: () => void) => {
    action();
    onClose();
  };

  const q = searchQuery.toLowerCase().trim();

  const matches = (text: string) => {
    if (!q) return true;
    return text.toLowerCase().includes(q);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
          />

          {/* Drawer slide-in panel */}
          <motion.aside
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 250 }}
            className="fixed inset-y-0 left-0 z-50 w-full max-w-xs bg-[#16171b] border-r border-white/10 text-white flex flex-col shadow-2xl overflow-hidden"
          >
            {/* Top brand header & close with WSTUDY branding */}
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center font-bold text-xs text-white shadow">
                  WS
                </div>
                <div>
                  <h3 className="font-bold text-sm tracking-tight text-white leading-none">WSTUDY Portal</h3>
                  <span className="text-[10px] text-gray-400 font-mono">WSTUDY Campus Network</span>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable menu content */}
            <div className="flex-1 overflow-y-auto px-3 py-4 space-y-4">
              {/* Search Menu Input */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search menu..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#1e2025] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-sm text-white placeholder-gray-400 focus:outline-none focus:border-amber-400/60 focus:ring-1 focus:ring-amber-400/40 transition-all"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white text-xs"
                  >
                    Clear
                  </button>
                )}
              </div>

              {/* WSpace Cloud Storage Card matching video */}
              {matches('wspace vspace storage drive files') && (
                <div
                  onClick={() => handleItemClick(onOpenWSpace)}
                  className="bg-[#1f2127] hover:bg-[#252830] transition-colors rounded-xl p-3 border border-white/10 cursor-pointer group"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                        <Cloud className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="font-semibold text-xs text-white">WSpace</span>
                        <div className="text-[11px] text-gray-400 font-mono">0 B of 1.00 GB</div>
                      </div>
                    </div>
                    <span className="text-xs font-mono font-semibold text-indigo-400">0%</span>
                  </div>
                  <div className="w-full h-1.5 bg-black/40 rounded-full mt-2.5 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 w-[2%] rounded-full" />
                  </div>
                </div>
              )}

              {/* Navigation Categories */}
              <div className="space-y-1">
                {/* 1. Notice Board */}
                {matches('notice board announcements') && (
                  <button
                    onClick={() => handleItemClick(() => onNavigate('notices'))}
                    className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-gray-300 hover:text-white hover:bg-white/5 transition-colors text-left cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <Megaphone className="w-4 h-4 text-emerald-400" />
                      <span className="text-sm font-medium">Notice Board</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300">
                        8
                      </span>
                      <ChevronRight className="w-4 h-4 text-gray-500" />
                    </div>
                  </button>
                )}

                {/* 2. Admissions */}
                {(matches('admissions dual program dashboard') || expandedSection === 'admissions') && (
                  <div className="rounded-xl overflow-hidden">
                    <button
                      onClick={() => toggleSection('admissions')}
                      className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors text-left cursor-pointer ${
                        expandedSection === 'admissions'
                          ? 'bg-white/10 text-white font-semibold'
                          : 'text-gray-300 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <GraduationCap className="w-4 h-4 text-amber-400" />
                        <span className="text-sm font-medium">Admissions</span>
                      </div>
                      {expandedSection === 'admissions' ? (
                        <ChevronDown className="w-4 h-4 text-amber-400" />
                      ) : (
                        <ChevronRight className="w-4 h-4 text-gray-500" />
                      )}
                    </button>

                    <AnimatePresence>
                      {expandedSection === 'admissions' && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="pl-9 pr-2 py-1 space-y-1 text-xs"
                        >
                          <button
                            onClick={() => handleItemClick(onOpenDualProgram)}
                            className="w-full text-left py-2 px-2.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 flex items-center gap-2 transition-colors cursor-pointer"
                          >
                            <BookOpen className="w-3.5 h-3.5 text-amber-300/80" />
                            <span>Apply Dual Program</span>
                          </button>
                          <button
                            onClick={() => handleItemClick(() => onNavigate('admissions', 'dashboard'))}
                            className="w-full text-left py-2 px-2.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 flex items-center gap-2 transition-colors cursor-pointer"
                          >
                            <FileText className="w-3.5 h-3.5 text-amber-300/80" />
                            <span>Admission Dashboard</span>
                          </button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}

                {/* 3. Transport & Hostel */}
                {(matches('transport hostel bus room mess') || expandedSection === 'transport') && (
                  <div className="rounded-xl overflow-hidden">
                    <button
                      onClick={() => toggleSection('transport')}
                      className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors text-left cursor-pointer ${
                        expandedSection === 'transport'
                          ? 'bg-white/10 text-white font-semibold'
                          : 'text-gray-300 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Bus className="w-4 h-4 text-sky-400" />
                        <span className="text-sm font-medium">Transport & Hostel</span>
                      </div>
                      {expandedSection === 'transport' ? (
                        <ChevronDown className="w-4 h-4 text-sky-400" />
                      ) : (
                        <ChevronRight className="w-4 h-4 text-gray-500" />
                      )}
                    </button>

                    <AnimatePresence>
                      {expandedSection === 'transport' && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="pl-9 pr-2 py-1 space-y-1 text-xs"
                        >
                          <button
                            onClick={() => handleItemClick(() => onOpenHostelTransport('transport'))}
                            className="w-full text-left py-2 px-2.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 flex items-center gap-2 transition-colors cursor-pointer"
                          >
                            <Bus className="w-3.5 h-3.5 text-sky-300/80" />
                            <span>Apply for Transport</span>
                          </button>
                          <button
                            onClick={() => handleItemClick(() => onOpenHostelTransport('hostel'))}
                            className="w-full text-left py-2 px-2.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 flex items-center gap-2 transition-colors cursor-pointer"
                          >
                            <Building className="w-3.5 h-3.5 text-sky-300/80" />
                            <span>Apply for Hostel</span>
                          </button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}

                {/* 4. My Learning (Accordion) */}
                {(matches('learning course enrollment od on-duty transcript classes') || expandedSection === 'learning') && (
                  <div className="rounded-xl overflow-hidden border border-white/5 bg-[#1b1c21]/50">
                    <button
                      onClick={() => toggleSection('learning')}
                      className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors text-left cursor-pointer ${
                        expandedSection === 'learning'
                          ? 'bg-white/10 text-white font-semibold'
                          : 'text-gray-300 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <BookOpen className="w-4 h-4 text-purple-400" />
                        <span className="text-sm font-medium">My Learning</span>
                      </div>
                      {expandedSection === 'learning' ? (
                        <ChevronDown className="w-4 h-4 text-purple-400" />
                      ) : (
                        <ChevronRight className="w-4 h-4 text-gray-500" />
                      )}
                    </button>

                    <AnimatePresence>
                      {expandedSection === 'learning' && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="pl-9 pr-2 py-1 space-y-1 text-xs"
                        >
                          <button
                            onClick={() => handleItemClick(onOpenCourseEnrollment)}
                            className="w-full text-left py-2 px-2.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 flex items-center gap-2 transition-colors cursor-pointer"
                          >
                            <CalendarCheck className="w-3.5 h-3.5 text-purple-300/80" />
                            <span>Course Enrollment</span>
                          </button>
                          <button
                            onClick={() => handleItemClick(onOpenCourseEnrollment)}
                            className="w-full text-left py-2 px-2.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 flex items-center gap-2 transition-colors cursor-pointer"
                          >
                            <CalendarCheck className="w-3.5 h-3.5 text-purple-300/80" />
                            <span>Late Course Enrollment</span>
                          </button>
                          <button
                            onClick={() => handleItemClick(onOpenODModal)}
                            className="w-full text-left py-2 px-2.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 flex items-center gap-2 transition-colors cursor-pointer"
                          >
                            <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="flex items-center gap-1.5">
                              On-Duty (OD)
                              <span className="text-[9px] px-1 py-0.2 bg-emerald-500/20 text-emerald-300 rounded font-semibold">Active</span>
                            </span>
                          </button>
                          <button
                            onClick={() => handleItemClick(() => onNavigate('transcript'))}
                            className="w-full text-left py-2 px-2.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 flex items-center gap-2 transition-colors cursor-pointer"
                          >
                            <Award className="w-3.5 h-3.5 text-amber-400" />
                            <span>Academic Transcript</span>
                          </button>

                          {/* My Courses Expandable List matching video at 00:27 */}
                          <div className="pt-1">
                            <button
                              onClick={() => setIsMyCoursesExpanded(!isMyCoursesExpanded)}
                              className="w-full text-left py-2 px-2.5 rounded-lg text-white font-semibold hover:bg-white/5 flex items-center justify-between transition-colors cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                <Layers className="w-3.5 h-3.5 text-purple-300" />
                                <span>My Courses</span>
                              </div>
                              <ChevronDown className={`w-3.5 h-3.5 text-gray-400 transition-transform ${isMyCoursesExpanded ? 'rotate-180' : ''}`} />
                            </button>

                            {isMyCoursesExpanded && (
                              <div className="pl-4 pr-1 py-1 space-y-1.5 border-l border-white/10 mt-1">
                                {allMyCoursesList.map((c) => (
                                  <button
                                    key={c.code}
                                    onClick={() => handleItemClick(() => onSelectCourseByCode(c.code))}
                                    className="w-full text-left p-1.5 rounded-lg hover:bg-white/10 transition-colors block cursor-pointer group"
                                  >
                                    <div className="font-bold text-[11px] text-white flex items-center gap-1.5">
                                      <span>{c.code} - {c.slot}</span>
                                    </div>
                                    <div className="text-[10px] text-gray-400 font-medium truncate group-hover:text-gray-200">
                                      {c.name}
                                    </div>
                                    <div className="text-[9px] text-gray-500 truncate">
                                      {c.faculty}
                                    </div>
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom student quick profile status */}
            <div className="p-3 border-t border-white/10 bg-[#121316]">
              <button
                onClick={() => handleItemClick(() => onNavigate('progress'))}
                className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 transition-colors text-left cursor-pointer"
              >
                <div className="w-9 h-9 rounded-full ring-2 ring-emerald-500/70 overflow-hidden flex-shrink-0 bg-gray-800">
                  <img
                    src={student.avatarUrl}
                    alt={student.name}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&h=120&q=80';
                    }}
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-semibold text-white truncate">{student.name}</div>
                  <div className="text-[10px] text-gray-400 font-mono">{student.registerNumber} · CSE</div>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-semibold font-mono">
                  {student.cgpa}
                </span>
              </button>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
};
