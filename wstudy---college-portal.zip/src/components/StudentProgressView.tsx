import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ChevronLeft,
  UserCheck,
  Award,
  Activity,
  Clock,
  BookMarked,
  AlertCircle,
  ShieldAlert,
  ShieldCheck,
  ExternalLink,
  Edit3,
  X,
  Check,
  GraduationCap,
  Sparkles
} from 'lucide-react';
import { StudentProfile, AcademicCoreProgress } from '../types';
import { CircularGauge } from './CircularGauge';

interface StudentProgressViewProps {
  student: StudentProfile;
  academicProgress: AcademicCoreProgress[];
  onBack: () => void;
  onUpdateSocialLinks?: (links: StudentProfile['socialLinks']) => void;
  onOpenMoodCheckIn?: () => void;
}

export const StudentProgressView: React.FC<StudentProgressViewProps> = ({
  student,
  academicProgress,
  onBack,
  onUpdateSocialLinks,
  onOpenMoodCheckIn
}) => {
  const [isEditingSocials, setIsEditingSocials] = useState(false);
  const [socialForm, setSocialForm] = useState(student.socialLinks);
  const [showDetailedBreakdown, setShowDetailedBreakdown] = useState(false);
  const [animatedCgpa, setAnimatedCgpa] = useState(0);

  // Animate CGPA count up on mount
  useEffect(() => {
    let current = 0;
    const target = student.cgpa;
    const step = target / 40;
    const timer = setInterval(() => {
      current += step;
      if (current >= target) {
        setAnimatedCgpa(target);
        clearInterval(timer);
      } else {
        setAnimatedCgpa(current);
      }
    }, 25);
    return () => clearInterval(timer);
  }, [student.cgpa]);

  const handleSaveSocials = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSocialLinks?.(socialForm);
    setIsEditingSocials(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.25 }}
      className="min-h-full pb-16 bg-[#121316] text-white"
    >
      {/* Top Nav Header */}
      <div className="sticky top-0 z-20 bg-[#121316]/95 backdrop-blur-md px-4 py-3 border-b border-white/10 flex items-center justify-between">
        <motion.button
          whileHover={{ scale: 1.05, x: -2 }}
          whileTap={{ scale: 0.95 }}
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm font-semibold text-gray-300 hover:text-white transition-colors cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5 text-gray-400" />
          <span>Back</span>
        </motion.button>
        <h1 className="text-base font-bold text-white tracking-tight flex items-center gap-1.5">
          <span>Student Progress</span>
          <Sparkles className="w-4 h-4 text-purple-400" />
        </h1>
        <div className="w-12" />
      </div>

      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        {/* Student Profile Card with Avatar & Identifiers */}
        <div className="flex flex-col items-center text-center">
          {/* Avatar with rotating vibrant gradient glow ring */}
          <div className="relative w-28 h-28 rounded-full p-1 shadow-[0_0_30px_rgba(168,85,247,0.45)]">
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-indigo-500 via-purple-500 via-pink-500 to-amber-500 animate-spin-slow opacity-90 blur-[1px]" />
            <div className="relative w-full h-full rounded-full p-0.5 bg-[#121316]">
              <img
                src={student.avatarUrl}
                alt={student.name}
                className="w-full h-full rounded-full object-cover bg-gray-900"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&h=200&q=80';
                }}
              />
            </div>
          </div>

          {/* Name & Role */}
          <motion.div
            initial={{ y: 10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="mt-3.5 flex items-center justify-center gap-2"
          >
            <h2 className="text-xl font-bold text-white tracking-tight">
              {student.name}
            </h2>
            <div className="p-1 rounded-full bg-white/10 text-gray-300" title="Student Verified">
              <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
            </div>
          </motion.div>

          {/* Roll Number & Program */}
          <div className="mt-1 text-sm font-mono text-gray-400">
            {student.registerNumber}
          </div>
          <div className="text-xs text-gray-400 mt-0.5">
            {student.degree} - {student.department}
          </div>

          {/* Overall CGPA Big Stat with animated counter */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 300, damping: 20 }}
            className="mt-5"
          >
            <div className="text-4xl font-extrabold text-[#3b82f6] tracking-tight font-mono-numbers">
              {animatedCgpa.toFixed(2)}
            </div>
            <div className="text-[11px] font-semibold text-gray-400 tracking-wider uppercase mt-1">
              OVERALL CGPA
            </div>
          </motion.div>

          {/* Credits & Status Pills */}
          <motion.div
            initial={{ y: 10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="mt-4 flex items-center gap-2.5"
          >
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1e2026] border border-white/10 text-xs text-gray-300">
              <GraduationCap className="w-3.5 h-3.5 text-gray-400" />
              <span>{student.creditsEarned} / {student.totalCredits} credits</span>
            </div>

            <div className="flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-xs font-semibold text-emerald-400">
              <Check className="w-3.5 h-3.5" />
              <span>{student.statusBadge}</span>
            </div>
          </motion.div>
        </div>

        {/* 2x2 Metric Quad Cards with rich hover and pulsing icons */}
        <div className="grid grid-cols-2 gap-3">
          {/* Happiness */}
          <motion.div
            whileHover={{ scale: 1.04, y: -2 }}
            whileTap={{ scale: 0.98 }}
            onClick={onOpenMoodCheckIn}
            className="bg-[#1c1d22] border border-white/5 rounded-2xl p-4 flex flex-col justify-between hover:bg-[#22242a] transition-all cursor-pointer group shadow-md"
          >
            <div className="text-indigo-400 animate-heartbeat">
              <Activity className="w-5 h-5" />
            </div>
            <div className="mt-3">
              <div className="text-2xl font-extrabold text-white font-mono-numbers">
                {student.happiness}%
              </div>
              <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mt-0.5 flex items-center justify-between">
                <span>HAPPINESS</span>
                <span className="text-[9px] text-indigo-400 group-hover:underline">Update</span>
              </div>
            </div>
          </motion.div>

          {/* Punctuality */}
          <motion.div
            whileHover={{ scale: 1.04, y: -2 }}
            className="bg-[#1c1d22] border border-white/5 rounded-2xl p-4 flex flex-col justify-between hover:bg-[#22242a] transition-all shadow-md"
          >
            <div className="text-emerald-400">
              <Clock className="w-5 h-5 animate-spin-slow" />
            </div>
            <div className="mt-3">
              <div className="text-2xl font-extrabold text-white font-mono-numbers">
                {student.punctuality}%
              </div>
              <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mt-0.5">
                PUNCTUALITY
              </div>
            </div>
          </motion.div>

          {/* Assignments */}
          <motion.div
            whileHover={{ scale: 1.04, y: -2 }}
            className="bg-[#1c1d22] border border-white/5 rounded-2xl p-4 flex flex-col justify-between hover:bg-[#22242a] transition-all shadow-md"
          >
            <div className="text-amber-400">
              <BookMarked className="w-5 h-5" />
            </div>
            <div className="mt-3">
              <div className="text-2xl font-extrabold text-white">
                {student.assignmentsCount}
              </div>
              <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mt-0.5">
                ASSIGNMENTS
              </div>
            </div>
          </motion.div>

          {/* Missed Tasks */}
          <motion.div
            whileHover={{ scale: 1.04, y: -2 }}
            className="bg-[#1c1d22] border border-white/5 rounded-2xl p-4 flex flex-col justify-between hover:bg-[#22242a] transition-all shadow-md"
          >
            <div className="text-rose-500">
              <AlertCircle className="w-5 h-5" />
            </div>
            <div className="mt-3">
              <div className="text-2xl font-extrabold text-rose-500 font-mono-numbers">
                {student.missedTasks}
              </div>
              <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mt-0.5">
                MISSED TASKS
              </div>
            </div>
          </motion.div>
        </div>

        {/* Academic Progress Section matching WhatsApp_Image_2026-11-01_at_11.20.26_PM__1__8dfc1799.jpeg */}
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-indigo-400" />
              <h3 className="font-bold text-sm tracking-tight text-white">
                Academic Progress
              </h3>
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowDetailedBreakdown(true)}
              className="text-xs font-semibold text-gray-400 hover:text-white px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 transition-colors border border-white/5 cursor-pointer"
            >
              View Details
            </motion.button>
          </div>

          {/* Core breakdown cards with animated bars */}
          <div className="space-y-2.5">
            {academicProgress.map((item, index) => {
              const pct = item.total > 0 ? (item.completed / item.total) * 100 : 0;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                  whileHover={{ scale: 1.02, x: 2 }}
                  className="bg-[#1a1b20] border border-white/5 rounded-2xl p-4 flex items-center justify-between transition-all hover:bg-[#202127] shadow-sm"
                >
                  <div className="flex items-center gap-4">
                    <div className="relative w-14 h-14 flex-shrink-0">
                      <CircularGauge
                        percentage={pct}
                        color={item.color}
                        size={56}
                        strokeWidth={5}
                        fractionText={`${item.completed}/${item.total}`}
                      />
                    </div>

                    <div>
                      <h4 className="font-semibold text-sm text-white">
                        {item.title}
                      </h4>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-gray-400">CGPA</span>
                        <span className="text-sm font-bold font-mono text-white">
                          {item.cgpa}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-medium text-gray-400">
                      {item.completed} of {item.total} Done
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Disciplinary Records */}
        <motion.div
          whileHover={{ scale: 1.02 }}
          className="bg-[#1a1b20] border border-white/5 rounded-2xl p-4 flex items-center justify-between shadow-sm"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-sm text-white">
                Disciplinary Records
              </div>
              <div className="text-xs text-gray-400 mt-0.5">
                Zero infractions · Exemplary conduct
              </div>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400 flex items-center gap-1">
            <ShieldCheck className="w-3 h-3" />
            Clean
          </span>
        </motion.div>

        {/* Social & Links Footer Bar */}
        <div className="pt-2">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <span className="text-xs font-bold uppercase tracking-wider text-gray-400">
              SOCIAL & LINKS
            </span>
            <button
              onClick={() => setIsEditingSocials(true)}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>&lt;/&gt; Edit</span>
            </button>
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            {student.socialLinks.github && (
              <motion.a
                whileHover={{ scale: 1.05 }}
                href={student.socialLinks.github}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-medium text-gray-300 hover:text-white flex items-center gap-1.5 transition-colors"
              >
                <span>GitHub</span>
                <ExternalLink className="w-3 h-3 text-gray-500" />
              </motion.a>
            )}
            {student.socialLinks.linkedin && (
              <motion.a
                whileHover={{ scale: 1.05 }}
                href={student.socialLinks.linkedin}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-medium text-gray-300 hover:text-white flex items-center gap-1.5 transition-colors"
              >
                <span>LinkedIn</span>
                <ExternalLink className="w-3 h-3 text-gray-500" />
              </motion.a>
            )}
            {student.socialLinks.portfolio && (
              <motion.a
                whileHover={{ scale: 1.05 }}
                href={student.socialLinks.portfolio}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-medium text-gray-300 hover:text-white flex items-center gap-1.5 transition-colors"
              >
                <span>Portfolio</span>
                <ExternalLink className="w-3 h-3 text-gray-500" />
              </motion.a>
            )}
            {student.socialLinks.leetcode && (
              <motion.a
                whileHover={{ scale: 1.05 }}
                href={student.socialLinks.leetcode}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-medium text-gray-300 hover:text-white flex items-center gap-1.5 transition-colors"
              >
                <span>LeetCode</span>
                <ExternalLink className="w-3 h-3 text-gray-500" />
              </motion.a>
            )}
          </div>
        </div>
      </div>

      {/* Edit Social Links Modal */}
      {isEditingSocials && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-sm bg-[#1b1c21] border border-white/10 rounded-3xl p-5 text-white shadow-2xl"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="font-bold text-sm">Edit Social & Profiles</h3>
              <button
                onClick={() => setIsEditingSocials(false)}
                className="p-1 rounded-full text-gray-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSocials} className="mt-4 space-y-3">
              <div>
                <label className="text-[11px] text-gray-400 font-medium">GitHub URL</label>
                <input
                  type="url"
                  value={socialForm.github || ''}
                  onChange={(e) => setSocialForm({ ...socialForm, github: e.target.value })}
                  placeholder="https://github.com/username"
                  className="w-full mt-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-400"
                />
              </div>
              <div>
                <label className="text-[11px] text-gray-400 font-medium">LinkedIn URL</label>
                <input
                  type="url"
                  value={socialForm.linkedin || ''}
                  onChange={(e) => setSocialForm({ ...socialForm, linkedin: e.target.value })}
                  placeholder="https://linkedin.com/in/username"
                  className="w-full mt-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-400"
                />
              </div>
              <div>
                <label className="text-[11px] text-gray-400 font-medium">Portfolio Website</label>
                <input
                  type="url"
                  value={socialForm.portfolio || ''}
                  onChange={(e) => setSocialForm({ ...socialForm, portfolio: e.target.value })}
                  placeholder="https://yourname.dev"
                  className="w-full mt-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-indigo-400"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsEditingSocials(false)}
                  className="px-3 py-2 rounded-xl text-xs text-gray-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-semibold text-white shadow-md cursor-pointer"
                >
                  Save Links
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* Detailed Academic Breakdown Modal */}
      {showDetailedBreakdown && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-md bg-[#1b1c21] border border-white/10 rounded-3xl p-6 text-white shadow-2xl max-h-[85vh] flex flex-col"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div>
                <h3 className="font-bold text-base">Curriculum Credit Audit</h3>
                <p className="text-xs text-gray-400">B.Tech CSE - 2026 Regulation</p>
              </div>
              <button
                onClick={() => setShowDetailedBreakdown(false)}
                className="p-1.5 rounded-full text-gray-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-4 space-y-4 text-xs">
              <div className="bg-[#121316] p-3.5 rounded-2xl border border-white/5">
                <div className="flex justify-between font-semibold text-white mb-1">
                  <span>Degree Completion</span>
                  <span className="text-indigo-400">12 / 192 Credits (6.25%)</span>
                </div>
                <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden mt-2">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: '6.25%' }}
                    transition={{ duration: 1 }}
                    className="h-full bg-gradient-to-r from-indigo-500 to-purple-500"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <h4 className="font-semibold text-gray-300">Category Requirements:</h4>
                <div className="p-3 bg-white/5 rounded-xl flex justify-between">
                  <span>Basic Science & Math (BSM)</span>
                  <span className="font-mono text-emerald-400">Completed 4 / 24</span>
                </div>
                <div className="p-3 bg-white/5 rounded-xl flex justify-between">
                  <span>Engineering Sciences (ESC)</span>
                  <span className="font-mono text-emerald-400">Completed 4 / 20</span>
                </div>
                <div className="p-3 bg-white/5 rounded-xl flex justify-between">
                  <span>Professional Core (PCC)</span>
                  <span className="font-mono text-amber-400">In Progress 4 / 64</span>
                </div>
                <div className="p-3 bg-white/5 rounded-xl flex justify-between">
                  <span>Humanities & Management (HSMC)</span>
                  <span className="font-mono text-gray-400">Pending 0 / 12</span>
                </div>
                <div className="p-3 bg-white/5 rounded-xl flex justify-between">
                  <span>Internship & Project Work</span>
                  <span className="font-mono text-gray-400">Pending 0 / 16</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-white/10 flex justify-end">
              <button
                onClick={() => setShowDetailedBreakdown(false)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white cursor-pointer"
              >
                Done
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
};
