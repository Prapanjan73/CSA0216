import React from 'react';
import { motion } from 'motion/react';
import { Calendar, Bell, MessageSquare, Menu, Smartphone, Monitor } from 'lucide-react';
import { StudentProfile } from '../types';

interface HeaderProps {
  student: StudentProfile;
  onOpenDrawer: () => void;
  onOpenTimetable: () => void;
  onOpenNotices: () => void;
  onToggleProfileMenu: (e: React.MouseEvent) => void;
  unreadNoticesCount?: number;
  isMobileFrame: boolean;
  onToggleMobileFrame: () => void;
  currentTitle?: string;
  onLogoClick: () => void;
  onOpenCommunityChat: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  student,
  onOpenDrawer,
  onOpenTimetable,
  onOpenNotices,
  onToggleProfileMenu,
  unreadNoticesCount = 8,
  isMobileFrame,
  onToggleMobileFrame,
  currentTitle = 'WStudy Portal',
  onLogoClick,
  onOpenCommunityChat
}) => {
  return (
    <header className="sticky top-0 z-30 w-full bg-[#121316]/95 backdrop-blur-md border-b border-white/10 px-4 py-2.5 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Left: Menu trigger & Animated Logo */}
        <div className="flex items-center gap-2.5">
          <motion.button
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.92 }}
            onClick={onOpenDrawer}
            className="p-2 rounded-xl text-gray-300 hover:text-white hover:bg-white/10 active:bg-white/15 transition-colors focus:outline-none cursor-pointer"
            aria-label="Open Navigation Menu"
            title="Menu"
          >
            <Menu className="w-5 h-5" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onLogoClick}
            className="flex items-center gap-2.5 group text-left focus:outline-none cursor-pointer"
          >
            {/* WStudy Circular Badge Logo with rotating glow */}
            <div className="relative w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 via-orange-500 to-indigo-600 p-[2px] shadow-[0_0_15px_rgba(245,158,11,0.3)] group-hover:shadow-[0_0_22px_rgba(245,158,11,0.6)] transition-all">
              <div className="w-full h-full rounded-full bg-[#16171b] flex items-center justify-center font-extrabold text-amber-400 text-sm tracking-tighter">
                <span className="bg-gradient-to-r from-amber-400 to-orange-400 bg-clip-text text-transparent">W</span>
                <span className="text-[10px] text-white">S</span>
              </div>
            </div>

            <div className="hidden sm:block">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-sm tracking-tight text-white group-hover:text-amber-300 transition-colors">
                  WSTUDY
                </span>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono font-medium">
                  vstudy
                </span>
              </div>
              <p className="text-[11px] text-gray-400 font-medium leading-none">
                WSTUDY Niana Study Portal
              </p>
            </div>
          </motion.button>
        </div>

        {/* Center: portal URL & context title on small view */}
        <div className="sm:hidden text-center">
          <div className="text-xs font-bold text-white tracking-tight flex items-center justify-center gap-1">
            <span>WSTUDY</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          </div>
          <div className="text-[10px] text-gray-400 font-mono">wstudy.geetha.com</div>
        </div>

        {/* Right side interactive animated icons */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Frame View Toggle */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onToggleMobileFrame}
            className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-gray-300 bg-white/5 hover:bg-white/10 hover:text-white transition-all border border-white/10 cursor-pointer"
            title={isMobileFrame ? 'Switch to Full Screen View' : 'Switch to Phone View'}
          >
            {isMobileFrame ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-amber-400" />
                <span>Full Web</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Phone View</span>
              </>
            )}
          </motion.button>

          {/* Timetable Icon */}
          <motion.button
            whileHover={{ scale: 1.1, rotate: -4 }}
            whileTap={{ scale: 0.9 }}
            onClick={onOpenTimetable}
            className="relative p-2 rounded-xl text-gray-300 hover:text-white hover:bg-white/10 active:bg-white/15 transition-all cursor-pointer"
            title="My Timetable"
            aria-label="My Timetable"
          >
            <Calendar className="w-5 h-5 text-gray-300 hover:text-amber-300 transition-colors" />
          </motion.button>

          {/* Notification Bell with Badge & subtle chime animation */}
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={onOpenNotices}
            className="relative p-2 rounded-xl text-gray-300 hover:text-white hover:bg-white/10 active:bg-white/15 transition-all cursor-pointer"
            title="Notice Board & Alerts"
            aria-label="Notice Board"
          >
            <Bell className={`w-5 h-5 text-gray-300 hover:text-emerald-300 transition-colors ${unreadNoticesCount > 0 ? 'animate-bell' : ''}`} />
            {unreadNoticesCount > 0 && (
              <span className="absolute top-1.5 right-1.5 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
            )}
          </motion.button>

          {/* Student Chat / Peer Forum */}
          <motion.button
            whileHover={{ scale: 1.1, rotate: 4 }}
            whileTap={{ scale: 0.9 }}
            onClick={onOpenCommunityChat}
            className="p-2 rounded-xl text-gray-300 hover:text-white hover:bg-white/10 active:bg-white/15 transition-all cursor-pointer"
            title="Student Community & Q&A"
            aria-label="Student Chat"
          >
            <MessageSquare className="w-5 h-5 text-gray-300 hover:text-sky-300 transition-colors" />
          </motion.button>

          {/* Student Avatar button with rotating glowing ring */}
          <motion.button
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.94 }}
            onClick={onToggleProfileMenu}
            className="relative ml-1 p-[2px] rounded-full bg-gradient-to-tr from-emerald-500 via-teal-400 to-indigo-500 hover:shadow-[0_0_15px_rgba(16,185,129,0.5)] focus:outline-none transition-all group cursor-pointer"
            title="Profile & Settings"
            aria-label="Student Profile Menu"
          >
            <img
              src={student.avatarUrl}
              alt={student.name}
              className="w-8 h-8 rounded-full object-cover bg-gray-800"
              onError={(e) => {
                (e.target as HTMLImageElement).src =
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&h=120&q=80';
              }}
            />
          </motion.button>
        </div>
      </div>
    </header>
  );
};
