import React, { useState } from 'react';
import { X, Bus, Building, MapPin, CheckCircle2, Ticket, Clock, Shield } from 'lucide-react';

interface HostelTransportModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'transport' | 'hostel';
}

export const HostelTransportModal: React.FC<HostelTransportModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'transport'
}) => {
  const [tab, setTab] = useState<'transport' | 'hostel'>(initialTab);
  const [selectedRoute, setSelectedRoute] = useState('Route 14: Tambaram to WStudy Campus');
  const [hostelRoom, setHostelRoom] = useState('Emerald Block - AC Room 304');
  const [applied, setApplied] = useState(false);

  if (!isOpen) return null;

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    setApplied(true);
    setTimeout(() => {
      setApplied(false);
      onClose();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#18191e] border border-white/10 rounded-3xl p-6 text-white shadow-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex bg-[#202229] p-1 rounded-xl border border-white/5">
            <button
              onClick={() => setTab('transport')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                tab === 'transport' ? 'bg-white text-gray-900 shadow' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Bus className="w-3.5 h-3.5" />
              <span>Transport</span>
            </button>
            <button
              onClick={() => setTab('hostel')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                tab === 'hostel' ? 'bg-white text-gray-900 shadow' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Building className="w-3.5 h-3.5" />
              <span>Hostel</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-full text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {applied ? (
          <div className="py-12 flex flex-col items-center text-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="text-base font-bold text-white">Application Recorded!</h4>
            <p className="text-xs text-gray-400 max-w-xs">
              Your {tab === 'transport' ? 'bus pass' : 'hostel accommodation'} request is being verified by the campus administrative office.
            </p>
          </div>
        ) : (
          <form onSubmit={handleApply} className="flex-1 overflow-y-auto py-4 space-y-4 text-xs">
            {tab === 'transport' ? (
              <>
                <div className="p-3 bg-[#202229] rounded-2xl border border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Ticket className="w-4 h-4 text-sky-400" />
                    <div>
                      <div className="font-semibold text-white">Current Bus Pass</div>
                      <div className="text-[10px] text-emerald-400">Active · Valid till Dec 2026</div>
                    </div>
                  </div>
                  <span className="font-mono text-xs bg-white/5 px-2 py-1 rounded">#BUS-2026-9092</span>
                </div>

                <div>
                  <label className="text-gray-300 font-medium">Select Bus Route</label>
                  <select
                    value={selectedRoute}
                    onChange={(e) => setSelectedRoute(e.target.value)}
                    className="w-full mt-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-sky-400"
                  >
                    <option>Route 14: Tambaram to WStudy Campus</option>
                    <option>Route 08: Anna Nagar to Campus via Maduravoyal</option>
                    <option>Route 21: Velachery & Guindy Express</option>
                    <option>Route 03: Avadi & Ambattur Route</option>
                    <option>Route 33: Chengalpattu / Kanchipuram Highway</option>
                  </select>
                </div>

                <div>
                  <label className="text-gray-300 font-medium">Boarding Point / Landmark</label>
                  <input
                    type="text"
                    defaultValue="Tambaram Sanatorium Bus Stand"
                    className="w-full mt-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-sky-400"
                  />
                </div>

                <div className="p-3 bg-sky-950/20 border border-sky-500/30 rounded-xl text-sky-300 space-y-1">
                  <div className="font-semibold flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    Pickup Schedule: 06:45 AM
                  </div>
                  <div className="text-[11px] text-sky-400">Live GPS tracking accessible once boarded via campus RFID card.</div>
                </div>
              </>
            ) : (
              <>
                <div className="p-3 bg-[#202229] rounded-2xl border border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Building className="w-4 h-4 text-purple-400" />
                    <div>
                      <div className="font-semibold text-white">Allocated Room</div>
                      <div className="text-[10px] text-purple-300">Emerald Men's Residency · Room 304</div>
                    </div>
                  </div>
                  <span className="font-mono text-xs bg-white/5 px-2 py-1 rounded">2-Sharing AC</span>
                </div>

                <div>
                  <label className="text-gray-300 font-medium">Hostel Block & Room Preference</label>
                  <select
                    value={hostelRoom}
                    onChange={(e) => setHostelRoom(e.target.value)}
                    className="w-full mt-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-400"
                  >
                    <option>Emerald Block - AC Room 304</option>
                    <option>Sapphire Residency - Non-AC 3 Sharing</option>
                    <option>Diamond Deluxe - Single Occupancy Suite</option>
                  </select>
                </div>

                <div>
                  <label className="text-gray-300 font-medium">Mess Meal Preference</label>
                  <select className="w-full mt-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-400">
                    <option>South Indian & North Indian Non-Veg (Standard)</option>
                    <option>Special Vegetarian & Jain Mess</option>
                    <option>Continental & Fitness High-Protein Mess</option>
                  </select>
                </div>

                <div className="p-3 bg-purple-950/20 border border-purple-500/30 rounded-xl text-purple-300 flex items-start gap-2">
                  <Shield className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span>24/7 Security & High-speed fiber WiFi enabled in all student hostel blocks.</span>
                </div>
              </>
            )}

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-gray-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-semibold text-white shadow-lg cursor-pointer"
              >
                Submit Request
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
