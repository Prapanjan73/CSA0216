import React, { useState } from 'react';
import { X, UserCheck, Calendar, FileText, CheckCircle2, Upload, AlertCircle } from 'lucide-react';

interface OnDutyModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultCourseCode?: string;
}

export const OnDutyModal: React.FC<OnDutyModalProps> = ({
  isOpen,
  onClose,
  defaultCourseCode = ''
}) => {
  const [reason, setReason] = useState('Hackathon / Symposium');
  const [fromDate, setFromDate] = useState('2026-11-04');
  const [toDate, setToDate] = useState('2026-11-05');
  const [courseCode, setCourseCode] = useState(defaultCourseCode);
  const [eventDetails, setEventDetails] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      onClose();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#18191e] border border-white/10 rounded-3xl p-6 text-white shadow-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-base">On-Duty (OD) Application</h3>
              <p className="text-xs text-gray-400">Formal attendance exemption request</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSubmitted ? (
          <div className="py-12 flex flex-col items-center text-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="text-base font-bold text-white">Application Submitted!</h4>
            <p className="text-xs text-gray-400 max-w-xs">
              Your request has been routed to Head of Department (CSE) and Class Advisor for digital sign-off.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto py-4 space-y-4 text-xs">
            {/* Category */}
            <div>
              <label className="text-gray-300 font-medium">OD Category</label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full mt-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-400"
              >
                <option value="Hackathon / Symposium">Inter-College Hackathon / Symposium</option>
                <option value="Paper Presentation">Technical Paper Presentation / IEEE Conference</option>
                <option value="Sports & Cultural">University Sports Tournament / Culturals</option>
                <option value="Medical Leave">Medical Leave (Hospital Admission/Doctor Advice)</option>
                <option value="Placement Interview">Off-Campus Placement / Internship Interview</option>
              </select>
            </div>

            {/* Date range */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-gray-300 font-medium">From Date</label>
                <input
                  type="date"
                  value={fromDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  className="w-full mt-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
              <div>
                <label className="text-gray-300 font-medium">To Date</label>
                <input
                  type="date"
                  value={toDate}
                  onChange={(e) => setToDate(e.target.value)}
                  className="w-full mt-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-400"
                />
              </div>
            </div>

            {/* Specific course exemption or All day */}
            <div>
              <label className="text-gray-300 font-medium">Affected Course Slot (Optional)</label>
              <input
                type="text"
                placeholder="e.g. CSA0216 or All Slots"
                value={courseCode}
                onChange={(e) => setCourseCode(e.target.value)}
                className="w-full mt-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
              />
            </div>

            {/* Event description */}
            <div>
              <label className="text-gray-300 font-medium">Event / Reason Details</label>
              <textarea
                rows={3}
                required
                placeholder="Provide event name, organizing institution, and role..."
                value={eventDetails}
                onChange={(e) => setEventDetails(e.target.value)}
                className="w-full mt-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400 resize-none"
              />
            </div>

            {/* Attachment Proof */}
            <div className="p-3 bg-[#202229] rounded-2xl border border-dashed border-white/15 text-center cursor-pointer hover:border-emerald-400/50 transition-colors">
              <Upload className="w-5 h-5 text-gray-400 mx-auto mb-1" />
              <div className="text-xs text-gray-300 font-medium">Upload Certificate / Hall Ticket / Permission Slip</div>
              <div className="text-[10px] text-gray-500">PDF, PNG, JPG up to 5 MB</div>
            </div>

            {/* Policy note */}
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-300 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <span>
                Maximum 12 OD days permitted per semester under University Academic Regulations.
              </span>
            </div>

            {/* Actions */}
            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-gray-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 font-semibold text-white shadow-lg cursor-pointer"
              >
                Submit Application
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
