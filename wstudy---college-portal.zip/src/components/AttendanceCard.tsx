import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, ChevronDown, Info, Sparkles } from 'lucide-react';
import { CourseSlot } from '../types';
import { CircularGauge } from './CircularGauge';

interface AttendanceCardProps {
  courseSlots: CourseSlot[];
  onSelectCourse: (course: CourseSlot) => void;
  selectedSemester?: string;
  onSemesterChange?: (sem: string) => void;
}

export const AttendanceCard: React.FC<AttendanceCardProps> = ({
  courseSlots,
  onSelectCourse,
  selectedSemester = 'MS2 Sep-Dec 2026 (UG)',
  onSemesterChange
}) => {
  const [isSemesterMenuOpen, setIsSemesterMenuOpen] = useState(false);

  const semesters = [
    'MS2 Sep-Dec 2026 (UG)',
    'MS1 Jun-Aug 2026 (UG)',
    'FS2 Jan-May 2026 (UG)',
    'FS1 Sep-Dec 2025 (UG)'
  ];

  return (
    <div className="w-full max-w-sm mx-auto">
      {/* Translucent Card matching screenshot WhatsApp_Image_2026-11-01_at_11.20.23_PM_9194c39d.jpeg */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="relative bg-white/94 backdrop-blur-xl rounded-[32px] p-5 shadow-[0_20px_50px_rgba(0,0,0,0.35)] border border-white/50 text-gray-900 transition-all overflow-hidden animate-float"
      >
        {/* Subtle glass shimmer reflection highlight */}
        <div className="absolute -top-16 -left-16 w-32 h-32 bg-white/40 rounded-full blur-2xl pointer-events-none" />

        {/* Semester selector pill */}
        <div className="relative inline-block mb-4">
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => setIsSemesterMenuOpen(!isSemesterMenuOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/5 hover:bg-black/10 active:bg-black/15 text-xs font-semibold text-gray-700 transition-colors cursor-pointer"
          >
            <Calendar className="w-3.5 h-3.5 text-gray-500" />
            <span>{selectedSemester}</span>
            <ChevronDown className={`w-3.5 h-3.5 text-gray-400 transition-transform duration-200 ${isSemesterMenuOpen ? 'rotate-180' : ''}`} />
          </motion.button>

          <AnimatePresence>
            {isSemesterMenuOpen && (
              <motion.div
                initial={{ opacity: 0, y: -6, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -6, scale: 0.95 }}
                transition={{ duration: 0.15 }}
                className="absolute top-full left-0 mt-1.5 z-20 w-56 bg-white rounded-2xl shadow-2xl border border-gray-100 py-1 overflow-hidden"
              >
                {semesters.map((sem) => (
                  <button
                    key={sem}
                    onClick={() => {
                      onSemesterChange?.(sem);
                      setIsSemesterMenuOpen(false);
                    }}
                    className={`w-full text-left px-3.5 py-2 text-xs font-medium transition-colors cursor-pointer ${
                      sem === selectedSemester
                        ? 'bg-emerald-50 text-emerald-700 font-semibold flex items-center justify-between'
                        : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <span>{sem}</span>
                    {sem === selectedSemester && (
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    )}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* 2x2 Attendance Grid */}
        <div className="grid grid-cols-2 gap-y-6 gap-x-4 py-1">
          {courseSlots.map((course, idx) => {
            const arcColor = course.percentage >= 80 ? '#22c55e' : '#f97316';

            return (
              <motion.div
                key={course.code}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.1 * idx, type: 'spring', stiffness: 300, damping: 20 }}
                whileHover={{ scale: 1.08, y: -3 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => onSelectCourse(course)}
                className="flex flex-col items-center cursor-pointer group p-2 rounded-2xl hover:bg-black/5 transition-all"
                title={`Click for ${course.title} details`}
              >
                {/* Circular Gauge with dynamic color */}
                <div className="relative">
                  <CircularGauge
                    percentage={course.percentage}
                    color={arcColor}
                    size={84}
                    strokeWidth={7}
                  />
                </div>

                {/* Slot Name & Code */}
                <div className="mt-2 text-center">
                  <div className="text-xs font-semibold text-gray-700 tracking-wider group-hover:text-black transition-colors">
                    {course.slot}
                  </div>
                  <div className="text-xs font-mono font-medium text-gray-500 group-hover:text-gray-700 transition-colors">
                    {course.code}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Bottom hint with animated pulse */}
        <div className="mt-4 pt-3 border-t border-gray-200/70 flex items-center justify-between text-[11px] text-gray-500 px-1">
          <span className="flex items-center gap-1">
            <Info className="w-3 h-3 text-emerald-600" />
            Min. required: 75%
          </span>
          <span className="font-semibold text-emerald-700 flex items-center gap-1">
            <span>Tap slot for logs</span>
            <span className="inline-block transition-transform group-hover:translate-x-1">→</span>
          </span>
        </div>
      </motion.div>
    </div>
  );
};
