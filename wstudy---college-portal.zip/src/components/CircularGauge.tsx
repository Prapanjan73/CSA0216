import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';

interface CircularGaugeProps {
  percentage: number;
  color?: string;
  size?: number;
  strokeWidth?: number;
  label?: string;
  subLabel?: string;
  fractionText?: string;
  showPercentSymbol?: boolean;
}

export const CircularGauge: React.FC<CircularGaugeProps> = ({
  percentage,
  color = '#22c55e',
  size = 80,
  strokeWidth = 6,
  label,
  subLabel,
  fractionText,
  showPercentSymbol = true
}) => {
  const [displayValue, setDisplayValue] = useState(0);

  // Smooth number count-up animation
  useEffect(() => {
    let start = 0;
    const end = Math.min(100, Math.max(0, percentage));
    if (end === 0) {
      setDisplayValue(0);
      return;
    }
    const duration = 1200; // ms
    const incrementTime = 25;
    const steps = duration / incrementTime;
    const stepValue = end / steps;

    const timer = setInterval(() => {
      start += stepValue;
      if (start >= end) {
        setDisplayValue(end);
        clearInterval(timer);
      } else {
        setDisplayValue(Math.round(start));
      }
    }, incrementTime);

    return () => clearInterval(timer);
  }, [percentage]);

  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.min(100, Math.max(0, percentage));
  const strokeDashoffset = circumference - (clamped / 100) * circumference;

  return (
    <div className="flex flex-col items-center select-none">
      <div
        className="relative flex items-center justify-center group"
        style={{ width: size, height: size }}
      >
        {/* Ambient glow behind gauge */}
        <div
          className="absolute inset-1 rounded-full opacity-20 blur-md transition-opacity duration-300 group-hover:opacity-50 pointer-events-none"
          style={{ backgroundColor: color }}
        />

        <svg
          className="transform -rotate-90 relative z-10"
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
        >
          {/* Background track circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="rgba(0, 0, 0, 0.08)"
            strokeWidth={strokeWidth}
            fill="transparent"
          />
          {/* Progress colored arc animated via motion */}
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={color}
            strokeWidth={strokeWidth}
            fill="transparent"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1] }}
            strokeLinecap="round"
          />
        </svg>

        {/* Center content with entrance scale and animated number */}
        <motion.div
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="absolute inset-0 flex flex-col items-center justify-center text-center z-10"
        >
          {fractionText ? (
            <span className="text-xs font-semibold text-white tracking-tight">
              {fractionText}
            </span>
          ) : (
            <span className="text-[15px] font-extrabold tracking-tight text-gray-900 dark:text-white font-mono-numbers">
              {displayValue}{showPercentSymbol && '%'}
            </span>
          )}
        </motion.div>
      </div>

      {label && (
        <span className="mt-2 text-xs font-medium text-gray-700 dark:text-gray-300 uppercase tracking-wider">
          {label}
        </span>
      )}
      {subLabel && (
        <span className="text-[11px] text-gray-500 dark:text-gray-400 font-mono-numbers">
          {subLabel}
        </span>
      )}
    </div>
  );
};
