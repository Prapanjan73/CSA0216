import React, { useRef, useEffect } from 'react';
import {
  User,
  ReceiptText,
  Wallet,
  ArrowLeftRight,
  SunMoon,
  Image as ImageIcon,
  LayoutGrid,
  LogOut,
  ChevronLeft
} from 'lucide-react';

interface ProfileDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectOption: (option: string) => void;
  currentTheme: string;
}

export const ProfileDropdown: React.FC<ProfileDropdownProps> = ({
  isOpen,
  onClose,
  onSelectOption,
  currentTheme
}) => {
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      ref={dropdownRef}
      className="absolute top-14 right-3 z-50 w-56 rounded-2xl bg-[#1e2025] border border-white/10 shadow-2xl p-2 text-white animate-scale-in"
    >
      <div className="space-y-0.5 text-xs font-medium">
        {/* Profile */}
        <button
          onClick={() => onSelectOption('profile')}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/10 transition-colors text-left text-gray-200 hover:text-white"
        >
          <User className="w-4 h-4 text-gray-400" />
          <span>Profile</span>
        </button>

        {/* Due List */}
        <button
          onClick={() => onSelectOption('duelist')}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/10 transition-colors text-left text-gray-200 hover:text-white"
        >
          <ReceiptText className="w-4 h-4 text-gray-400" />
          <span>Due List</span>
        </button>

        {/* Wallets */}
        <button
          onClick={() => onSelectOption('wallets')}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/10 transition-colors text-left text-gray-200 hover:text-white"
        >
          <Wallet className="w-4 h-4 text-gray-400" />
          <span>Wallets</span>
        </button>

        {/* External Credits */}
        <button
          onClick={() => onSelectOption('credits')}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-white/10 transition-colors text-left text-gray-200 hover:text-white"
        >
          <ArrowLeftRight className="w-4 h-4 text-gray-400" />
          <span>External Credits</span>
        </button>

        {/* Divider */}
        <div className="my-1 border-t border-white/5" />

        {/* < Theme */}
        <button
          onClick={() => onSelectOption('theme')}
          className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-white/10 transition-colors text-left text-gray-200 hover:text-white"
        >
          <div className="flex items-center gap-2">
            <ChevronLeft className="w-3.5 h-3.5 text-gray-500" />
            <span>Theme</span>
          </div>
          <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-white/10 text-gray-400">
            {currentTheme}
          </span>
        </button>

        {/* < Wallpaper */}
        <button
          onClick={() => onSelectOption('wallpaper')}
          className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-white/10 transition-colors text-left text-gray-200 hover:text-white"
        >
          <div className="flex items-center gap-2">
            <ChevronLeft className="w-3.5 h-3.5 text-gray-500" />
            <span>Wallpaper</span>
          </div>
          <ImageIcon className="w-3.5 h-3.5 text-gray-500" />
        </button>

        {/* < Widgets */}
        <button
          onClick={() => onSelectOption('widgets')}
          className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-white/10 transition-colors text-left text-gray-200 hover:text-white"
        >
          <div className="flex items-center gap-2">
            <ChevronLeft className="w-3.5 h-3.5 text-gray-500" />
            <span>Widgets</span>
          </div>
          <LayoutGrid className="w-3.5 h-3.5 text-gray-500" />
        </button>

        {/* Divider */}
        <div className="my-1 border-t border-white/5" />

        {/* Logout */}
        <button
          onClick={() => onSelectOption('logout')}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-rose-500/15 text-rose-400 hover:text-rose-300 transition-colors text-left"
        >
          <LogOut className="w-4 h-4" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};
