import React, { useState } from 'react';
import { X, ReceiptText, CheckCircle2, AlertCircle, CreditCard, Download } from 'lucide-react';
import { DueListItem } from '../types';

interface DueListModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: DueListItem[];
  onPayDue: (id: string) => void;
}

export const DueListModal: React.FC<DueListModalProps> = ({
  isOpen,
  onClose,
  items,
  onPayDue
}) => {
  const [payingId, setPayingId] = useState<string | null>(null);

  if (!isOpen) return null;

  const totalPending = items
    .filter((i) => i.status === 'Pending')
    .reduce((sum, item) => sum + item.amount, 0);

  const handlePay = (id: string) => {
    setPayingId(id);
    setTimeout(() => {
      onPayDue(id);
      setPayingId(null);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#18191e] border border-white/10 rounded-3xl p-6 text-white shadow-2xl max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <ReceiptText className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="font-bold text-base">Student Due List</h3>
              <p className="text-xs text-gray-400">Account statement & fee clearance</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4">
          {/* Summary Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-transparent border border-amber-500/20 flex items-center justify-between">
            <div>
              <span className="text-[11px] font-semibold text-amber-300 uppercase tracking-wider">
                Total Outstanding
              </span>
              <div className="text-2xl font-extrabold text-white mt-0.5">
                ₹{totalPending.toLocaleString('en-IN')}
              </div>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 font-semibold">
              {totalPending === 0 ? 'All Clear' : 'Action Required'}
            </span>
          </div>

          {/* Dues List */}
          <div className="space-y-2.5">
            {items.map((item) => (
              <div
                key={item.id}
                className="p-3.5 rounded-2xl bg-[#202229] border border-white/5 flex items-center justify-between text-xs"
              >
                <div className="space-y-1 max-w-[240px]">
                  <div className="font-semibold text-white">{item.category}</div>
                  <div className="text-gray-400 text-[11px] leading-tight">{item.description}</div>
                  <div className="text-[10px] text-gray-500 font-mono">Due: {item.dueDate}</div>
                </div>

                <div className="text-right space-y-2">
                  <div className="font-bold text-sm text-white">
                    ₹{item.amount.toLocaleString('en-IN')}
                  </div>
                  {item.status === 'Paid' ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Paid
                    </span>
                  ) : (
                    <button
                      onClick={() => handlePay(item.id)}
                      disabled={payingId === item.id}
                      className="px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-black font-bold text-[11px] transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <CreditCard className="w-3 h-3" />
                      <span>{payingId === item.id ? 'Processing...' : 'Pay Now'}</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-gray-400">
          <span>Fee queries: accounts@wstudy.edu</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
