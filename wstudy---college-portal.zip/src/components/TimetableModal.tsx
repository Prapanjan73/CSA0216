import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Calendar as CalendarIcon,
  X,
  ChevronLeft,
  ChevronRight,
  RotateCw,
  Clock,
  MapPin,
  User
} from 'lucide-react';
import { TimetableDay, TimetableClass } from '../types';

interface TimetableModalProps {
  isOpen: boolean;
  onClose: () => void;
  timetableDays: TimetableDay[];
  onSelectCourse?: (code: string) => void;
}

export const TimetableModal: React.FC<TimetableModalProps> = ({
  isOpen,
  onClose,
  timetableDays,
  onSelectCourse
}) => {
  const [activeView, setActiveView] = useState<'week' | 'month'>('week');
  const [selectedClass, setSelectedClass] = useState<TimetableClass | null>(null);
  const [weekIndex, setWeekIndex] = useState(0);

  if (!isOpen) return null;

  const weekLabels = [
    'Oct 26 – Nov 1',
    'Nov 2 – Nov 8',
    'Nov 9 – Nov 15',
    'Nov 16 – Nov 22'
  ];

  const hours = ['8 AM', '9 AM', '10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM'];

  // Days for Week View (Mon to Fri) matching video at 00:42
  const weekDays = [
    {
      name: 'MON',
      date: 26,
      slots: [
        { code: 'CSA0216', name: 'C PROGRAMMING', faculty: 'Dr. Marcus Vance', time: '08:00–11:00', color: 'bg-blue-600', text: 'text-blue-100', top: 0, height: 120 },
        { code: 'BTA0105', name: 'BIOLOGY & ENV', faculty: 'Dr. Elena Rostova', time: '12:00–15:00', color: 'bg-rose-600', text: 'text-rose-100', top: 160, height: 120 }
      ]
    },
    {
      name: 'TUE',
      date: 27,
      slots: [
        { code: 'EEA0115', name: 'BASIC ELECTRICAL', faculty: 'Prof. Julian Sterling', time: '08:00–11:00', color: 'bg-emerald-600', text: 'text-emerald-100', top: 0, height: 120 },
        { code: 'UBA0603', name: 'APPLIED MATH', faculty: 'Dr. Sophia Martinez', time: '12:00–15:00', color: 'bg-amber-600', text: 'text-amber-100', top: 160, height: 120 }
      ]
    },
    {
      name: 'WED',
      date: 28,
      slots: [
        { code: 'BTA0105', name: 'BIOLOGY & ENV', faculty: 'Dr. Elena Rostova', time: '08:00–11:00', color: 'bg-rose-600', text: 'text-rose-100', top: 0, height: 120 },
        { code: 'CSA0216', name: 'C PROGRAMMING', faculty: 'Dr. Marcus Vance', time: '12:00–15:00', color: 'bg-blue-600', text: 'text-blue-100', top: 160, height: 120 }
      ]
    },
    {
      name: 'THU',
      date: 29,
      slots: [
        { code: 'UBA0603', name: 'APPLIED MATH', faculty: 'Dr. Sophia Martinez', time: '08:00–11:00', color: 'bg-amber-600', text: 'text-amber-100', top: 0, height: 120 },
        { code: 'EEA0115', name: 'BASIC ELECTRICAL', faculty: 'Prof. Julian Sterling', time: '12:00–15:00', color: 'bg-emerald-600', text: 'text-emerald-100', top: 160, height: 120 }
      ]
    },
    {
      name: 'FRI',
      date: 30,
      slots: [
        { code: 'CSA0216', name: 'C PROGRAMMING', faculty: 'Dr. Marcus Vance', time: '08:00–11:00', color: 'bg-blue-600', text: 'text-blue-100', top: 0, height: 120 },
        { code: 'BTA0105', name: 'BIOLOGY & ENV', faculty: 'Dr. Elena Rostova', time: '12:00–15:00', color: 'bg-rose-600', text: 'text-rose-100', top: 160, height: 120 }
      ]
    }
  ];

  const getPillStyle = (variant: TimetableClass['colorVariant']) => {
    switch (variant) {
      case 'blue':
        return { stripe: 'bg-blue-500', badge: 'text-blue-300', bg: 'bg-[#22252e] hover:bg-[#282c37]' };
      case 'red':
        return { stripe: 'bg-rose-500', badge: 'text-rose-300', bg: 'bg-[#252227] hover:bg-[#2e2830]' };
      case 'green':
        return { stripe: 'bg-emerald-500', badge: 'text-emerald-300', bg: 'bg-[#1e2622] hover:bg-[#24302a]' };
      case 'amber':
        return { stripe: 'bg-amber-500', badge: 'text-amber-300', bg: 'bg-[#28251e] hover:bg-[#312c22]' };
      default:
        return { stripe: 'bg-purple-500', badge: 'text-purple-300', bg: 'bg-[#24222a] hover:bg-[#2d2935]' };
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg bg-[#16171b] border border-white/10 rounded-3xl text-white shadow-2xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Top Header matching video at 00:41 */}
        <div className="p-4 border-b border-white/10 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-gray-300" />
            <h2 className="text-sm font-bold text-white tracking-tight">
              My Timetable
            </h2>
          </div>

          {/* Week | Month Switcher */}
          <div className="flex items-center bg-[#222329] p-0.5 rounded-xl border border-white/5">
            <button
              onClick={() => setActiveView('week')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeView === 'week'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Week
            </button>
            <button
              onClick={() => setActiveView('month')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeView === 'month'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Month
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-gray-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub-header navigation row */}
        <div className="px-4 py-2 bg-[#1b1c22] border-b border-white/5 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setWeekIndex((prev) => Math.max(0, prev - 1))}
              className="p-1 rounded text-gray-400 hover:text-white cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-semibold text-white">
              {weekLabels[weekIndex]}
            </span>
            <button
              onClick={() => setWeekIndex((prev) => Math.min(weekLabels.length - 1, prev + 1))}
              className="p-1 rounded text-gray-400 hover:text-white cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setWeekIndex(0)}
              className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300 text-xs font-medium cursor-pointer"
            >
              Today
            </button>
            <button
              onClick={() => {}}
              className="p-1 rounded text-gray-400 hover:text-white cursor-pointer"
              title="Refresh"
            >
              <RotateCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* VIEW 1: Authentic Weekly Calendar Grid (matching video 00:42) */}
        {activeView === 'week' ? (
          <div className="flex-1 overflow-x-auto overflow-y-auto p-3">
            <div className="min-w-[420px]">
              {/* Day column headers */}
              <div className="grid grid-cols-6 border-b border-white/10 pb-2 text-center text-xs">
                <div className="text-gray-500 font-mono text-[10px]">TIME</div>
                {weekDays.map((d) => (
                  <div key={d.name} className="space-y-0.5">
                    <div className="text-[10px] text-gray-400 font-semibold">{d.name}</div>
                    <div className="text-xs font-bold text-white">{d.date}</div>
                  </div>
                ))}
              </div>

              {/* Time grid with colored course cards */}
              <div className="relative mt-2" style={{ height: '320px' }}>
                {/* Horizontal hour lines */}
                {hours.map((hr, idx) => (
                  <div
                    key={hr}
                    className="absolute left-0 right-0 border-t border-white/5 flex items-center text-[10px] text-gray-500 font-mono"
                    style={{ top: `${idx * 40}px` }}
                  >
                    <span className="w-12 text-left">{hr}</span>
                  </div>
                ))}

                {/* Day Slot Columns */}
                <div className="absolute left-12 right-0 top-0 bottom-0 grid grid-cols-5 gap-1.5">
                  {weekDays.map((day) => (
                    <div key={day.name} className="relative h-full">
                      {day.slots.map((slot, sIdx) => (
                        <div
                          key={sIdx}
                          onClick={() => onSelectCourse?.(slot.code)}
                          className={`absolute left-0 right-0 rounded-xl p-2 cursor-pointer shadow-lg transition-transform hover:scale-105 ${slot.color} ${slot.text}`}
                          style={{
                            top: `${slot.top}px`,
                            height: `${slot.height}px`
                          }}
                        >
                          <div className="text-[10px] font-bold font-mono tracking-tight leading-none">
                            {slot.code}
                          </div>
                          <div className="text-[11px] font-extrabold leading-tight mt-1 line-clamp-2">
                            {slot.name}
                          </div>
                          <div className="text-[9px] opacity-80 mt-1 truncate">
                            {slot.faculty}
                          </div>
                          <div className="text-[9px] font-mono opacity-90 mt-auto pt-2 flex items-center gap-0.5">
                            <Clock className="w-2.5 h-2.5" />
                            <span>{slot.time}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* VIEW 2: Month View (matching video 00:46) */
          <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
            {timetableDays.map((day) => {
              const isToday = day.dateNum === 2;
              return (
                <div
                  key={day.fullDate}
                  className="flex items-start gap-3 py-1.5 border-b border-white/5 last:border-0"
                >
                  <div
                    className={`w-12 py-2 rounded-xl text-center flex-shrink-0 transition-colors ${
                      isToday
                        ? 'bg-indigo-600/30 border border-indigo-500/40 text-indigo-300'
                        : 'bg-[#202127] border border-white/5 text-gray-400'
                    }`}
                  >
                    <div className="text-[10px] font-bold tracking-wider">{day.dayName}</div>
                    <div className="text-sm font-extrabold text-white mt-0.5">{day.dateNum}</div>
                  </div>

                  <div className="flex-1 min-w-0 space-y-1.5 pt-0.5">
                    {day.classes.length === 0 ? (
                      <div className="py-2.5 px-3 rounded-xl bg-[#1b1c21]/50 text-xs text-gray-500 italic">
                        No classes
                      </div>
                    ) : (
                      day.classes.map((cls, idx) => {
                        const style = getPillStyle(cls.colorVariant);
                        return (
                          <div
                            key={idx}
                            onClick={() => onSelectCourse?.(cls.code)}
                            className={`relative flex items-center justify-between px-3 py-2 rounded-xl border border-white/5 cursor-pointer transition-all ${style.bg}`}
                          >
                            <div className={`absolute left-0 inset-y-0 w-1 ${style.stripe} rounded-l-xl`} />
                            <div className="pl-1.5 flex items-center gap-2">
                              <span className="text-xs font-bold font-mono text-white">
                                {cls.code}
                              </span>
                              <span className="text-gray-500 text-xs">·</span>
                              <span className={`text-[11px] font-semibold ${style.badge}`}>
                                {cls.slot}
                              </span>
                            </div>
                            <div className="flex items-center gap-1 text-[11px] font-mono text-gray-400">
                              <Clock className="w-3 h-3 text-gray-500" />
                              <span>{cls.time}</span>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
