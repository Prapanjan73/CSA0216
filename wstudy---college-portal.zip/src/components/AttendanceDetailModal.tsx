import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle2, AlertTriangle, User, MapPin, Calendar, PlusCircle } from 'lucide-react';
import { CourseSlot } from '../types';
import { CircularGauge } from './CircularGauge';

interface AttendanceDetailModalProps {
  course: CourseSlot | null;
  onClose: () => void;
  onApplyOD: (courseCode: string) => void;
}

export const AttendanceDetailModal: React.FC<AttendanceDetailModalProps> = ({
  course,
  onClose,
  onApplyOD
}) => {
  const [simulatedClasses, setSimulatedClasses] = useState(0);

  if (!course) return null;

  // Margin calculation
  // Target is 75%
  // attended / (total) >= 0.75
  // If current > 75%, how many can be missed:
  // (attended) / (total + x) >= 0.75 => total + x <= attended / 0.75 => x = floor(attended / 0.75 - total)
  const safeMissable = Math.max(0, Math.floor(course.attendedClasses / 0.75 - course.totalClasses));

  // If < 75%, how many needed:
  // (attended + y) / (total + y) >= 0.75 => attended + y >= 0.75*total + 0.75*y => 0.25*y >= 0.75*total - attended => y = ceil((0.75*total - attended)/0.25)
  const neededClasses = Math.max(0, Math.ceil((0.75 * course.totalClasses - course.attendedClasses) / 0.25));

  // Simulation calculation
  const simTotal = course.totalClasses + simulatedClasses;
  const simAttended = course.attendedClasses + simulatedClasses;
  const simPercentage = Math.round((simAttended / simTotal) * 100);

  const mockLogs = [
    { date: 'Oct 31, 2026', time: '08:00 - 11:00', status: 'Present', topic: 'Binary Search Trees & Balancing' },
    { date: 'Oct 28, 2026', time: '08:00 - 11:00', status: 'Present', topic: 'AVL Tree Rotations' },
    { date: 'Oct 24, 2026', time: '08:00 - 11:00', status: 'Absent', topic: 'Red-Black Trees Introduction', canOD: true },
    { date: 'Oct 21, 2026', time: '08:00 - 11:00', status: 'Present', topic: 'B-Trees & Multiway Search' },
    { date: 'Oct 17, 2026', time: '08:00 - 11:00', status: 'OD Approved', topic: 'Symposium Participation' }
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-lg bg-[#18191e] border border-white/10 rounded-3xl p-6 text-white shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        >
          {/* Header */}
          <div className="flex items-start justify-between pb-4 border-b border-white/10">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 font-mono">
                  {course.slot}
                </span>
                <span className="text-xs font-mono text-gray-400">
                  {course.code}
                </span>
                <span className="text-xs text-gray-400">· {course.credits} Credits</span>
              </div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                {course.title}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-full text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Modal Body */}
          <div className="flex-1 overflow-y-auto py-4 space-y-5">
            {/* Top stats card */}
            <div className="bg-[#202228] rounded-2xl p-4 border border-white/5 flex items-center justify-between">
              <div className="space-y-1.5">
                <div className="text-xs text-gray-400 font-medium">Attendance Status</div>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-extrabold text-white">
                    {course.attendedClasses} / {course.totalClasses}
                  </span>
                  <span className="text-xs text-gray-400">classes</span>
                </div>
                {course.percentage >= 75 ? (
                  <div className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Safe: You can miss {safeMissable} more classes</span>
                  </div>
                ) : (
                  <div className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-400">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Warning: Attend {neededClasses} classes to reach 75%</span>
                  </div>
                )}
              </div>

              <div>
                <CircularGauge
                  percentage={course.percentage}
                  color={course.percentage >= 80 ? '#22c55e' : '#f97316'}
                  size={76}
                  strokeWidth={6}
                />
              </div>
            </div>

            {/* Course metadata */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="bg-[#202228] p-3 rounded-xl border border-white/5 flex items-start gap-2.5">
                <User className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
                <div>
                  <div className="text-gray-400">Instructor</div>
                  <div className="font-semibold text-white mt-0.5">{course.faculty}</div>
                </div>
              </div>
              <div className="bg-[#202228] p-3 rounded-xl border border-white/5 flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-sky-400 mt-0.5 flex-shrink-0" />
                <div>
                  <div className="text-gray-400">Location</div>
                  <div className="font-semibold text-white mt-0.5">{course.venue}</div>
                </div>
              </div>
            </div>

            {/* Attendance Simulator */}
            <div className="bg-[#202228]/80 rounded-2xl p-4 border border-white/5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-gray-300">
                  Attendance Simulator
                </span>
                <span className="text-xs font-mono font-bold text-amber-400">
                  {simPercentage}% (+{simulatedClasses} classes)
                </span>
              </div>
              <p className="text-[11px] text-gray-400 mb-3">
                See your projected percentage if you attend upcoming sessions:
              </p>
              <div className="flex items-center gap-2">
                {[1, 2, 3, 5, 8].map((num) => (
                  <button
                    key={num}
                    onClick={() => setSimulatedClasses(num)}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-medium transition-all ${
                      simulatedClasses === num
                        ? 'bg-amber-500 text-black font-bold'
                        : 'bg-white/5 text-gray-300 hover:bg-white/10'
                    }`}
                  >
                    +{num}
                  </button>
                ))}
                {simulatedClasses > 0 && (
                  <button
                    onClick={() => setSimulatedClasses(0)}
                    className="px-2 py-1.5 rounded-lg text-xs text-gray-400 hover:text-white"
                  >
                    Reset
                  </button>
                )}
              </div>
            </div>

            {/* Recent Attendance Log entries */}
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-gray-400">
                  Recent Class Logs
                </h4>
                <button
                  onClick={() => onApplyOD(course.code)}
                  className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>Apply OD for Absent</span>
                </button>
              </div>

              <div className="space-y-2">
                {mockLogs.map((log, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-[#202228] border border-white/5 text-xs"
                  >
                    <div>
                      <div className="font-medium text-white">{log.topic}</div>
                      <div className="text-[11px] text-gray-400 flex items-center gap-2 mt-0.5">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {log.date}
                        </span>
                        <span>{log.time}</span>
                      </div>
                    </div>
                    <div>
                      {log.status === 'Present' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400">
                          Present
                        </span>
                      )}
                      {log.status === 'Absent' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-400">
                          Absent
                        </span>
                      )}
                      {log.status === 'OD Approved' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300">
                          OD Approved
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Footer Action */}
          <div className="pt-3 border-t border-white/10 flex justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-medium text-white transition-colors"
            >
              Close
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
