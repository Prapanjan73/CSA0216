import React, { useState } from 'react';
import { X, MessageSquare, Send, User, Sparkles, Smile } from 'lucide-react';

interface CampusChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  studentName?: string;
}

interface ChatMessage {
  id: string;
  sender: string;
  text: string;
  time: string;
  isMe: boolean;
  tag?: string;
}

export const CampusChatModal: React.FC<CampusChatModalProps> = ({
  isOpen,
  onClose,
  studentName = 'Aarav Sharma'
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm-1',
      sender: 'Dr. Marcus Vance (Prof / CSE)',
      text: 'Good morning students, please submit the DSA Assignment 2 BST balancing lab code before 5 PM today.',
      time: '09:15 AM',
      isMe: false,
      tag: 'Faculty'
    },
    {
      id: 'm-2',
      sender: 'Jordan Blake (Class Rep)',
      text: 'Reminder: TechFest 2026 symposium registration counter is open at SCAD ground floor.',
      time: '10:30 AM',
      isMe: false,
      tag: 'CR'
    },
    {
      id: 'm-3',
      sender: studentName,
      text: 'Has the venue for afternoon Slot B (Biotech) been shifted to Hall 102?',
      time: '10:45 AM',
      isMe: true
    },
    {
      id: 'm-4',
      sender: 'Dr. Elena Rostova (Biotech)',
      text: `Yes ${studentName.split(' ')[0]}, Hall 102 SCAD building as notified.`,
      time: '10:48 AM',
      isMe: false,
      tag: 'Faculty'
    }
  ]);
  const [inputText, setInputText] = useState('');

  if (!isOpen) return null;

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const newMsg: ChatMessage = {
      id: `m-${Date.now()}`,
      sender: studentName,
      text: inputText.trim(),
      time: 'Just now',
      isMe: true
    };
    setMessages([...messages, newMsg]);
    setInputText('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#18191e] border border-white/10 rounded-3xl p-5 text-white shadow-2xl max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-base">Campus Student Chat</h3>
              <p className="text-xs text-gray-400">CSE Batch 2026 Official Channel</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto py-3 space-y-3">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.isMe ? 'items-end' : 'items-start'}`}
            >
              <div className="flex items-center gap-1.5 mb-1 px-1">
                <span className="text-[11px] font-semibold text-gray-300">{msg.sender}</span>
                {msg.tag && (
                  <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 font-semibold font-mono">
                    {msg.tag}
                  </span>
                )}
                <span className="text-[10px] text-gray-500 font-mono">{msg.time}</span>
              </div>
              <div
                className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed ${
                  msg.isMe
                    ? 'bg-emerald-600 text-white rounded-br-none shadow-md'
                    : 'bg-[#22242c] text-gray-200 border border-white/5 rounded-bl-none'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
        </div>

        {/* Chat input */}
        <form onSubmit={handleSend} className="pt-2 border-t border-white/10 flex items-center gap-2">
          <input
            type="text"
            placeholder="Type your message or question..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="flex-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
          />
          <button
            type="submit"
            className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer shadow transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
