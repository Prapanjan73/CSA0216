import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ChevronLeft, Award, CheckCircle2, XCircle, Download } from 'lucide-react';
import { TranscriptCourse } from '../types';

interface AcademicTranscriptViewProps {
  courses: TranscriptCourse[];
  overallCgpa: number;
  onBack: () => void;
}

export const AcademicTranscriptView: React.FC<AcademicTranscriptViewProps> = ({
  courses,
  overallCgpa = 8.67,
  onBack
}) => {
  const [filter, setFilter] = useState<'all' | 'completed' | 'failed'>('all');

  const completedCount = courses.filter((c) => c.status === 'Completed').length;
  const failedCount = courses.filter((c) => c.status === 'Failed Exam').length;

  const filteredCourses = courses.filter((c) => {
    if (filter === 'completed') return c.status === 'Completed';
    if (filter === 'failed') return c.status === 'Failed Exam';
    return true;
  });

  return (
    <div className="min-h-full pb-16 bg-[#121316] text-white">
      {/* Top Header matching video at 00:30 */}
      <div className="sticky top-0 z-20 bg-[#121316]/95 backdrop-blur-md px-4 py-3 border-b border-white/10 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm font-semibold text-gray-300 hover:text-white transition-colors cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5 text-gray-400" />
          <span>Back</span>
        </button>
        <h1 className="text-base font-bold text-white tracking-tight">
          Academic Transcript
        </h1>
        <button
          onClick={() => alert('Downloading official stamped PDF transcript...')}
          className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300"
          title="Download Transcript PDF"
        >
          <Download className="w-4 h-4" />
        </button>
      </div>

      <div className="max-w-md mx-auto px-4 py-4 space-y-4">
        {/* Top Summary Banner matching video */}
        <div className="flex items-center justify-between text-xs">
          <div className="text-gray-300 font-semibold">
            {courses.length} courses
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-gray-400 font-medium">OVERALL CGPA</span>
            <span className="text-base font-extrabold text-[#3b82f6] font-mono">
              {overallCgpa.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Filter Pills matching video tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              filter === 'all'
                ? 'bg-white/20 text-white shadow'
                : 'bg-[#1c1d22] text-gray-400 hover:text-white'
            }`}
          >
            All {courses.length}
          </button>
          <button
            onClick={() => setFilter('completed')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              filter === 'completed'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                : 'bg-[#1c1d22] text-gray-400 hover:text-white'
            }`}
          >
            Completed {completedCount}
          </button>
          <button
            onClick={() => setFilter('failed')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              filter === 'failed'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                : 'bg-[#1c1d22] text-gray-400 hover:text-white'
            }`}
          >
            Failed Exam {failedCount}
          </button>
        </div>

        {/* Transcript Table matching video table */}
        <div className="bg-[#18191e] border border-white/5 rounded-2xl overflow-hidden">
          <div className="p-3 border-b border-white/5 grid grid-cols-12 text-[10px] font-bold text-gray-400 tracking-wider uppercase text-left">
            <div className="col-span-5">COURSE NAME</div>
            <div className="col-span-4">TYPE</div>
            <div className="col-span-3 text-right">STATUS</div>
          </div>

          <div className="divide-y divide-white/5">
            {filteredCourses.map((c) => (
              <div
                key={c.code}
                className="p-3 grid grid-cols-12 items-center text-xs transition-colors hover:bg-white/5"
              >
                {/* Course Name & Code */}
                <div className="col-span-5 pr-2">
                  <div className="font-bold text-white text-[11px] leading-tight">
                    {c.name}
                  </div>
                  <div className="text-[10px] text-gray-400 font-mono mt-0.5">
                    {c.code} · {c.credits} Cr
                  </div>
                </div>

                {/* Course Type */}
                <div className="col-span-4">
                  <span
                    className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-semibold ${
                      c.type === 'Program Core'
                        ? 'bg-purple-950/60 text-purple-300 border border-purple-500/30'
                        : 'bg-blue-950/60 text-blue-300 border border-blue-500/30'
                    }`}
                  >
                    {c.type}
                  </span>
                </div>

                {/* Status & Grade */}
                <div className="col-span-3 text-right">
                  {c.status === 'Completed' ? (
                    <span className="inline-block px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-950/60 text-emerald-400 border border-emerald-500/30">
                      Completed
                    </span>
                  ) : (
                    <span className="inline-block px-2 py-0.5 rounded-md text-[10px] font-bold bg-rose-950/60 text-rose-400 border border-rose-500/30">
                      Failed Exam
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Note */}
        <div className="p-3 bg-white/5 rounded-xl text-[11px] text-gray-400 leading-relaxed">
          * Re-appear examinations for failed subjects will be scheduled alongside the MS2 End-Semester Examination.
        </div>
      </div>
    </div>
  );
};
