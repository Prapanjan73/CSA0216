import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Sparkles, CheckCircle2 } from 'lucide-react';

interface MoodCheckInModalProps {
  isOpen: boolean;
  onClose: () => void;
  studentName?: string;
  onMoodSelected: (moodRating: number) => void;
}

export const MoodCheckInModal: React.FC<MoodCheckInModalProps> = ({
  isOpen,
  onClose,
  studentName = 'Aarav',
  onMoodSelected
}) => {
  const [selectedMood, setSelectedMood] = useState<number>(4); // Default to 4: Good
  const [isSubmitting, setIsSubmitting] = useState(false);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  };

  const moods = [
    { rating: 1, label: 'Very Bad', bg: 'bg-[#fce7f3]', text: 'text-[#e11d48]', border: 'border-[#fda4af]', glow: 'rgba(244,63,94,0.4)' },
    { rating: 2, label: 'Bad', bg: 'bg-[#ffedd5]', text: 'text-[#ea580c]', border: 'border-[#fdba74]', glow: 'rgba(249,115,22,0.4)' },
    { rating: 3, label: 'Okay', bg: 'bg-[#fef9c3]', text: 'text-[#ca8a04]', border: 'border-[#fde047]', glow: 'rgba(234,179,8,0.4)' },
    { rating: 4, label: 'Good', bg: 'bg-[#dcfce7]', text: 'text-[#16a34a]', border: 'border-[#86efac]', glow: 'rgba(34,197,94,0.4)' },
    { rating: 5, label: 'Very Happy', bg: 'bg-[#ccfbf1]', text: 'text-[#0d9488]', border: 'border-[#5eead4]', glow: 'rgba(20,184,166,0.4)' }
  ];

  const handleStartDay = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      onMoodSelected(selectedMood);
      setIsSubmitting(false);
      onClose();
    }, 600);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.88, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.88, y: 30 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-sm overflow-hidden rounded-[28px] bg-[#1a1b1f] border border-white/10 p-6 text-white shadow-[0_25px_60px_-15px_rgba(0,0,0,0.7)]"
        >
          {/* Subtle animated background gradient orb */}
          <div
            className="absolute -top-12 -right-12 w-36 h-36 rounded-full blur-3xl opacity-20 pointer-events-none transition-colors duration-500"
            style={{ backgroundColor: moods[selectedMood - 1].glow }}
          />

          {/* Close button in corner */}
          <motion.button
            whileHover={{ scale: 1.15, rotate: 90 }}
            whileTap={{ scale: 0.85 }}
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full text-gray-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Dismiss"
          >
            <X className="w-5 h-5" />
          </motion.button>

          {/* Heading */}
          <div className="text-center mt-1">
            <motion.h2
              initial={{ y: -10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="text-xl font-bold tracking-tight text-white flex items-center justify-center gap-1.5"
            >
              <span>{getGreeting()}, {studentName}!</span>
              <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
            </motion.h2>
            <p className="mt-1 text-sm text-gray-400">
              Let's check in before we start.
            </p>
          </div>

          {/* Animated Interactive Smiley Face */}
          <div className="my-6 flex justify-center">
            <motion.div
              key={selectedMood}
              initial={{ scale: 0.75, rotate: -10 }}
              animate={{ scale: [0.75, 1.08, 1], rotate: [-10, 5, 0] }}
              transition={{ type: 'spring', stiffness: 400, damping: 15 }}
              whileHover={{ scale: 1.06, rotate: 3 }}
              className="relative w-24 h-24 rounded-full bg-gradient-to-b from-[#fcd34d] via-[#fbbf24] to-[#f59e0b] shadow-[0_10px_30px_rgba(245,158,11,0.4)] flex items-center justify-center border-2 border-[#fef08a] cursor-pointer"
            >
              <svg width="68" height="68" viewBox="0 0 100 100" fill="none">
                {/* Eyes */}
                {selectedMood === 1 ? (
                  <>
                    <path d="M28 42 L40 46" stroke="#451a03" strokeWidth="4.5" strokeLinecap="round" />
                    <path d="M72 42 L60 46" stroke="#451a03" strokeWidth="4.5" strokeLinecap="round" />
                  </>
                ) : selectedMood === 2 ? (
                  <>
                    <circle cx="34" cy="42" r="5" fill="#451a03" />
                    <circle cx="66" cy="42" r="5" fill="#451a03" />
                  </>
                ) : selectedMood === 3 ? (
                  <>
                    <circle cx="34" cy="42" r="5.5" fill="#451a03" />
                    <circle cx="66" cy="42" r="5.5" fill="#451a03" />
                  </>
                ) : selectedMood === 4 ? (
                  <>
                    <circle cx="34" cy="40" r="6" fill="#451a03" />
                    <circle cx="66" cy="40" r="6" fill="#451a03" />
                    <path d="M30 34 Q34 31 38 34" stroke="#451a03" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                    <path d="M62 34 Q66 31 70 34" stroke="#451a03" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                  </>
                ) : (
                  <>
                    {/* Happy crescent eyes */}
                    <path d="M28 44 Q34 34 40 44" stroke="#451a03" strokeWidth="4.5" strokeLinecap="round" fill="none" />
                    <path d="M60 44 Q66 34 72 44" stroke="#451a03" strokeWidth="4.5" strokeLinecap="round" fill="none" />
                    <ellipse cx="26" cy="52" rx="6" ry="3.5" fill="#f87171" opacity="0.6" />
                    <ellipse cx="74" cy="52" rx="6" ry="3.5" fill="#f87171" opacity="0.6" />
                  </>
                )}

                {/* Mouth */}
                {selectedMood === 1 ? (
                  <path d="M32 68 Q50 52 68 68" stroke="#451a03" strokeWidth="4.5" strokeLinecap="round" fill="none" />
                ) : selectedMood === 2 ? (
                  <path d="M34 66 Q50 58 66 66" stroke="#451a03" strokeWidth="4.5" strokeLinecap="round" fill="none" />
                ) : selectedMood === 3 ? (
                  <path d="M36 64 L64 64" stroke="#451a03" strokeWidth="4.5" strokeLinecap="round" fill="none" />
                ) : selectedMood === 4 ? (
                  <path d="M32 58 Q50 72 68 58" stroke="#451a03" strokeWidth="4.5" strokeLinecap="round" fill="none" />
                ) : (
                  <path d="M30 56 Q50 78 70 56 Z" fill="#451a03" stroke="#451a03" strokeWidth="2" strokeLinejoin="round" />
                )}
              </svg>
            </motion.div>
          </div>

          <div className="text-center text-sm font-medium text-gray-300 mb-4">
            Select a mood
          </div>

          {/* Mood 1 to 5 selector pills with spring bounce */}
          <div className="grid grid-cols-5 gap-2 px-1">
            {moods.map((m) => {
              const isSelected = selectedMood === m.rating;
              return (
                <motion.button
                  key={m.rating}
                  type="button"
                  whileHover={{ scale: 1.12, y: -2 }}
                  whileTap={{ scale: 0.92 }}
                  onClick={() => setSelectedMood(m.rating)}
                  className="flex flex-col items-center group focus:outline-none cursor-pointer"
                >
                  <motion.div
                    animate={isSelected ? { scale: [1, 1.18, 1.1] } : { scale: 1 }}
                    transition={{ type: 'spring', stiffness: 500, damping: 20 }}
                    className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-base transition-all duration-200 ${m.bg} ${m.text} ${
                      isSelected
                        ? `ring-4 ring-white/30 shadow-lg ${m.border} border-2`
                        : 'opacity-85 hover:opacity-100'
                    }`}
                  >
                    {m.rating}
                  </motion.div>
                  <span
                    className={`mt-2 text-[11px] text-center font-medium leading-tight transition-colors ${
                      isSelected ? 'text-white font-semibold' : 'text-gray-400 group-hover:text-gray-200'
                    }`}
                  >
                    {m.label}
                  </span>
                </motion.button>
              );
            })}
          </div>

          {/* "Start my Day" CTA button with ripple/glow */}
          <div className="mt-8">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleStartDay}
              disabled={isSubmitting}
              className="relative w-full py-3.5 px-4 rounded-xl bg-[#24262b] hover:bg-[#2c2f36] active:bg-[#1f2125] text-white font-medium text-sm border border-white/10 shadow-lg transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer overflow-hidden group"
            >
              {/* Shimmer sweep effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
              
              {isSubmitting ? (
                <>
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 0.8, ease: 'linear' }}
                    className="w-4 h-4 border-2 border-emerald-400 border-t-transparent rounded-full"
                  />
                  <span>Updating Campus Mood...</span>
                </>
              ) : (
                <span>Start my Day</span>
              )}
            </motion.button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
