import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  ChevronLeft,
  RotateCw,
  Bookmark,
  BookmarkCheck,
  FileImage,
  Share2,
  Search,
  Filter,
  CheckCircle,
  X
} from 'lucide-react';
import { PortalNotice } from '../types';

interface NoticeBoardViewProps {
  notices: PortalNotice[];
  onBack: () => void;
  onToggleBookmark: (noticeId: string) => void;
}

export const NoticeBoardView: React.FC<NoticeBoardViewProps> = ({
  notices,
  onBack,
  onToggleBookmark
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'myBoard'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedNotice, setSelectedNotice] = useState<PortalNotice | null>(null);
  const [copyFeedback, setCopyFeedback] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 600);
  };

  const handleShare = (notice: PortalNotice) => {
    if (navigator.share) {
      navigator.share({
        title: notice.title,
        text: notice.body
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(`${notice.title}\n${notice.body}`);
      setCopyFeedback(true);
      setTimeout(() => setCopyFeedback(false), 2000);
    }
  };

  const filteredNotices = notices.filter((n) => {
    if (activeTab === 'myBoard' && !n.isBookmarked) return false;
    if (selectedCategory !== 'ALL' && n.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        n.title.toLowerCase().includes(q) ||
        n.body.toLowerCase().includes(q) ||
        n.author.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="min-h-full pb-16 bg-[#121316] text-white">
      {/* Top Bar matching WhatsApp_Image_2026-11-01_at_11.20.24_PM_6dfabafc.jpeg */}
      <div className="sticky top-0 z-20 bg-[#121316]/95 backdrop-blur-md px-4 py-3 border-b border-white/10 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm font-semibold text-gray-300 hover:text-white transition-colors cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5 text-gray-400" />
          <span>Back</span>
        </button>
        <h1 className="text-base font-bold text-white tracking-tight">
          Notice Board
        </h1>
        <div className="w-12" />
      </div>

      <div className="max-w-md mx-auto px-4 py-4 space-y-4">
        {/* Two main tabs: "Notice Board" | "My Board" */}
        <div className="flex items-center justify-between">
          <div className="flex bg-[#1c1d22] p-1 rounded-2xl border border-white/5">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-white/10 text-white shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Notice Board
            </button>
            <button
              onClick={() => setActiveTab('myBoard')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'myBoard'
                  ? 'bg-white/10 text-white shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              My Board
            </button>
          </div>

          {/* Refresh action */}
          <button
            onClick={handleRefresh}
            className="p-2 rounded-xl bg-[#1c1d22] border border-white/5 text-gray-400 hover:text-white transition-colors"
            title="Refresh Notices"
          >
            <RotateCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-emerald-400' : ''}`} />
          </button>
        </div>

        {/* Count & Search status */}
        <div className="flex items-center justify-between text-xs text-gray-400 px-1">
          <span>{filteredNotices.length} notices for you</span>
          {activeTab === 'myBoard' && (
            <span className="text-[11px] text-amber-400">Bookmarked</span>
          )}
        </div>

        {/* Search bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search circulars, exams, events..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#1c1d22] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
          />
        </div>

        {/* Notice Cards List */}
        <div className="space-y-3.5">
          {filteredNotices.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-12 bg-[#18191e] rounded-2xl border border-white/5 p-6"
            >
              <Bookmark className="w-8 h-8 text-gray-600 mx-auto mb-2" />
              <p className="text-sm font-medium text-gray-400">No notices found</p>
              <p className="text-xs text-gray-500 mt-1">
                {activeTab === 'myBoard' ? 'You have not saved any notices to your board yet.' : 'Try adjusting your search query.'}
              </p>
            </motion.div>
          ) : (
            filteredNotices.map((notice, index) => (
              <motion.div
                key={notice.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 * index }}
                whileHover={{ y: -2 }}
                className="relative bg-[#1a1b20] rounded-2xl border border-white/5 overflow-hidden transition-all hover:border-white/15 shadow-sm"
              >
                {/* Left vertical green border bar accent matching screenshot */}
                <div className="absolute left-0 inset-y-0 w-1 bg-emerald-500 rounded-l-2xl" />

                <div className="p-4 pl-4.5">
                  {/* Title & Category Badge */}
                  <div className="flex items-start justify-between gap-2">
                    <h3
                      onClick={() => setSelectedNotice(notice)}
                      className="font-bold text-sm text-white tracking-tight hover:text-emerald-300 transition-colors cursor-pointer"
                    >
                      {notice.title}
                    </h3>
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-bold tracking-wider bg-emerald-950/60 text-emerald-400 border border-emerald-500/20 uppercase flex-shrink-0">
                      {notice.category}
                    </span>
                  </div>

                  {/* Author & Timestamp */}
                  <div className="mt-1 text-xs text-gray-400">
                    <span>{notice.author}</span>
                    <span className="mx-1.5">·</span>
                    <span>{notice.timestamp}</span>
                  </div>

                  {/* Audience */}
                  <div className="mt-1.5 flex items-center gap-1.5 text-[11px] text-gray-400">
                    <span className="text-gray-500">👥</span>
                    <span>{notice.audience}</span>
                  </div>

                  {/* Body Content preview if provided */}
                  {notice.body && (
                    <div className="mt-2 text-xs text-gray-300 leading-relaxed line-clamp-3">
                      {notice.body}
                    </div>
                  )}

                  {/* Attachment chip if present */}
                  {notice.attachmentName && (
                    <div className="mt-3 flex items-center gap-2">
                      <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#24262d] border border-white/5 text-[11px] text-gray-300 hover:text-white cursor-pointer hover:bg-[#2c2e36] transition-colors">
                        <FileImage className="w-3.5 h-3.5 text-rose-400" />
                        <span className="truncate max-w-[200px]">{notice.attachmentName}</span>
                      </div>
                    </div>
                  )}

                  {/* Actions Footer */}
                  <div className="mt-3 pt-2.5 border-t border-white/5 flex items-center justify-between text-xs">
                    <button
                      onClick={() => setSelectedNotice(notice)}
                      className="text-emerald-400 hover:text-emerald-300 font-medium text-[11px]"
                    >
                      Read full announcement →
                    </button>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleShare(notice)}
                        className="p-1 rounded text-gray-400 hover:text-white transition-colors"
                        title="Share notice"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onToggleBookmark(notice.id)}
                        className={`p-1 rounded transition-colors ${
                          notice.isBookmarked ? 'text-amber-400' : 'text-gray-400 hover:text-white'
                        }`}
                        title={notice.isBookmarked ? 'Remove from My Board' : 'Save to My Board'}
                      >
                        {notice.isBookmarked ? (
                          <BookmarkCheck className="w-4 h-4 fill-amber-400" />
                        ) : (
                          <Bookmark className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>

      {/* Notice Reader Modal */}
      {selectedNotice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#18191e] border border-white/10 rounded-3xl p-6 text-white shadow-2xl max-h-[85vh] flex flex-col">
            <div className="flex items-start justify-between pb-3 border-b border-white/10">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 uppercase">
                  {selectedNotice.category}
                </span>
                <h3 className="font-bold text-base mt-1.5 text-white">
                  {selectedNotice.title}
                </h3>
                <div className="text-xs text-gray-400 mt-1">
                  {selectedNotice.author} · {selectedNotice.timestamp}
                </div>
              </div>
              <button
                onClick={() => setSelectedNotice(null)}
                className="p-1.5 rounded-full text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-4 text-xs text-gray-200 whitespace-pre-line leading-relaxed space-y-4">
              <div className="bg-[#121316] p-3 rounded-xl border border-white/5 text-[11px] text-gray-400">
                Audience: <span className="text-white font-medium">{selectedNotice.audience}</span>
              </div>
              <p>{selectedNotice.body}</p>

              {selectedNotice.attachmentName && (
                <div className="p-3 bg-[#202228] rounded-xl border border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileImage className="w-4 h-4 text-rose-400" />
                    <div>
                      <div className="text-xs font-medium text-white">{selectedNotice.attachmentName}</div>
                      <div className="text-[10px] text-gray-400">Attachment · 1.4 MB</div>
                    </div>
                  </div>
                  <button
                    onClick={() => alert(`Downloading attachment: ${selectedNotice.attachmentName}`)}
                    className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-[11px] text-white"
                  >
                    Download
                  </button>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-white/10 flex justify-between items-center">
              <button
                onClick={() => onToggleBookmark(selectedNotice.id)}
                className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-xl transition-colors ${
                  selectedNotice.isBookmarked
                    ? 'bg-amber-500/20 text-amber-300'
                    : 'bg-white/5 text-gray-300 hover:text-white'
                }`}
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>{selectedNotice.isBookmarked ? 'Bookmarked' : 'Add to My Board'}</span>
              </button>

              <button
                onClick={() => setSelectedNotice(null)}
                className="px-4 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Copy feedback toast */}
      {copyFeedback && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full bg-emerald-500 text-black font-semibold text-xs flex items-center gap-1.5 shadow-xl">
          <CheckCircle className="w-4 h-4" />
          <span>Notice copied to clipboard</span>
        </div>
      )}
    </div>
  );
};
