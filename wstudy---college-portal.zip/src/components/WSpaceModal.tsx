import React, { useState } from 'react';
import { X, Cloud, Upload, FileText, Trash2, Download, HardDrive } from 'lucide-react';
import { WSpaceFile } from '../types';

interface WSpaceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WSpaceModal: React.FC<WSpaceModalProps> = ({
  isOpen,
  onClose
}) => {
  const [files, setFiles] = useState<WSpaceFile[]>([
    { id: 'f-1', name: 'DSA_Unit1_Notes_Stacks_Queues.pdf', size: '2.4 MB', sizeBytes: 2516582, uploadDate: 'Oct 28, 2026', category: 'Notes' },
    { id: 'f-2', name: 'Biotech_Lab_Experiment_3_Report.docx', size: '1.1 MB', sizeBytes: 1153433, uploadDate: 'Oct 24, 2026', category: 'Lab Manuals' },
    { id: 'f-3', name: 'IEEE_Paper_Registration_Receipt.pdf', size: '480 KB', sizeBytes: 491520, uploadDate: 'Oct 19, 2026', category: 'Certificates' }
  ]);

  if (!isOpen) return null;

  const totalUsedBytes = files.reduce((acc, f) => acc + f.sizeBytes, 0);
  const totalMaxBytes = 1024 * 1024 * 1024; // 1.00 GB
  const usedMB = (totalUsedBytes / (1024 * 1024)).toFixed(1);
  const usedPercent = Math.max(0.5, ((totalUsedBytes / totalMaxBytes) * 100)).toFixed(1);

  const handleDelete = (id: string) => {
    setFiles(files.filter((f) => f.id !== id));
  };

  const handleUploadSim = () => {
    const newFile: WSpaceFile = {
      id: `f-${Date.now()}`,
      name: `Lecture_Slides_Week_${files.length + 1}.pdf`,
      size: '3.2 MB',
      sizeBytes: 3355443,
      uploadDate: 'Just now',
      category: 'Notes'
    };
    setFiles([newFile, ...files]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#18191e] border border-white/10 rounded-3xl p-6 text-white shadow-2xl max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base">WSpace Student Cloud</h3>
              <p className="text-xs text-gray-400">Secure campus document repository</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Storage Bar Card */}
        <div className="mt-4 p-4 rounded-2xl bg-[#202229] border border-white/5 space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-gray-400 flex items-center gap-1.5">
              <HardDrive className="w-3.5 h-3.5 text-indigo-400" />
              <span>Storage Usage</span>
            </span>
            <span className="font-mono font-bold text-indigo-300">
              {usedMB} MB of 1.00 GB ({usedPercent}%)
            </span>
          </div>
          <div className="w-full h-2 bg-black/40 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, Math.max(3, parseFloat(usedPercent)))}%` }}
            />
          </div>
        </div>

        {/* Upload Action */}
        <div className="mt-3">
          <button
            onClick={handleUploadSim}
            className="w-full py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-white flex items-center justify-center gap-2 border border-white/10 cursor-pointer transition-colors"
          >
            <Upload className="w-4 h-4 text-emerald-400" />
            <span>Upload Document / Notes</span>
          </button>
        </div>

        {/* File List */}
        <div className="flex-1 overflow-y-auto py-3 space-y-2">
          <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">
            Your Uploaded Files ({files.length})
          </span>
          {files.map((file) => (
            <div
              key={file.id}
              className="p-3 rounded-xl bg-[#202229] border border-white/5 flex items-center justify-between text-xs group hover:bg-[#252830] transition-colors"
            >
              <div className="flex items-center gap-2.5 min-w-0 pr-2">
                <FileText className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                <div className="min-w-0">
                  <div className="font-medium text-white truncate max-w-[210px]">{file.name}</div>
                  <div className="text-[10px] text-gray-400 font-mono">
                    {file.size} · {file.uploadDate}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => alert(`Downloading ${file.name}`)}
                  className="p-1 rounded text-gray-400 hover:text-white"
                  title="Download file"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => handleDelete(file.id)}
                  className="p-1 rounded text-gray-400 hover:text-rose-400"
                  title="Delete file"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-medium text-white"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
