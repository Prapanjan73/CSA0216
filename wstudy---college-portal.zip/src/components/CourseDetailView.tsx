import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  ChevronLeft,
  Calendar,
  FileText,
  CheckCircle2,
  XCircle,
  Download,
  AlertCircle,
  Clock,
  BookOpen,
  ListTodo,
  Layers
} from 'lucide-react';
import { CourseSlot } from '../types';

interface CourseDetailViewProps {
  course: CourseSlot;
  onBack: () => void;
  onOpenTimetable?: () => void;
}

export const CourseDetailView: React.FC<CourseDetailViewProps> = ({
  course,
  onBack,
  onOpenTimetable
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'topics' | 'sessions' | 'todo' | 'attendance'>('overview');

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'topics', label: 'Topics' },
    { id: 'sessions', label: 'Sessions' },
    { id: 'todo', label: 'To Do' },
    { id: 'attendance', label: 'Attendance' }
  ] as const;

  const totalSessions = course.totalClasses || 25;
  const presentCount = course.attendedClasses || 21;
  const absentCount = totalSessions - presentCount;
  const attendancePct = ((presentCount / totalSessions) * 100).toFixed(2);

  return (
    <div className="min-h-full pb-16 bg-[#121316] text-white">
      {/* Top Header matching video at 00:07 */}
      <div className="sticky top-0 z-20 bg-[#121316]/95 backdrop-blur-md px-4 py-3 border-b border-white/10 flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm font-semibold text-gray-300 hover:text-white transition-colors cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5 text-gray-400" />
          <span>Back</span>
        </button>
        <div className="text-center font-bold text-sm tracking-tight text-white truncate max-w-[210px]">
          {course.code} - {course.title}
        </div>
        <button
          onClick={onOpenTimetable}
          className="p-1 rounded text-gray-400 hover:text-white"
          title="Course Timetable"
        >
          <Calendar className="w-4 h-4 text-gray-300" />
        </button>
      </div>

      <div className="max-w-md mx-auto px-4 py-4 space-y-4">
        {/* Course Banner */}
        <div className="bg-[#18191e] border border-white/5 rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white tracking-tight">
              {course.code} - {course.title}
            </h2>
            <button
              onClick={onOpenTimetable}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-gray-300"
            >
              <Calendar className="w-4 h-4" />
            </button>
          </div>
          <div className="text-xs text-gray-400 mt-1 font-mono">
            MS2 Sep-Dec 2026 (UG) · {course.slot} · {course.faculty}
          </div>
        </div>

        {/* Tab Bar switcher matching video */}
        <div className="flex bg-[#1c1d22] p-1 rounded-2xl border border-white/5 overflow-x-auto no-scrollbar gap-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-white/15 text-white shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab 1: Overview */}
        {activeTab === 'overview' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4 text-xs"
          >
            {/* Course Goals */}
            <div className="bg-[#18191e] border border-white/5 rounded-2xl p-4 space-y-2.5">
              <div className="flex items-center gap-2 font-bold text-sm text-white">
                <BookOpen className="w-4 h-4 text-indigo-400" />
                <span>Course Goals</span>
              </div>
              <div className="space-y-2 text-gray-300 leading-relaxed pl-1">
                {course.goals && course.goals.length > 0 ? (
                  course.goals.map((goal, idx) => (
                    <p key={idx}>{goal}</p>
                  ))
                ) : (
                  <>
                    <p>1. To familiarize the basic concepts of computer programming.</p>
                    <p>2. To provide knowledge on syntax and semantics of "C" language.</p>
                    <p>3. To learn how to write modular and readable C Programs.</p>
                    <p>4. To write programs using structured programming approach to solve problems.</p>
                    <p>5. To provide training in writing efficient, maintainable and portable code.</p>
                  </>
                )}
              </div>
            </div>

            {/* Previous Course Committee Report */}
            <div className="bg-[#18191e] border border-white/5 rounded-2xl p-4 space-y-2.5">
              <div className="flex items-center gap-2 font-bold text-sm text-white">
                <FileText className="w-4 h-4 text-amber-400" />
                <span>Previous Course Committee Report</span>
              </div>
              <div className="p-3 bg-[#202229] rounded-xl border border-white/5 flex items-center justify-between text-xs hover:bg-[#262831] transition-colors cursor-pointer">
                <div className="flex items-center gap-2.5 min-w-0">
                  <FileText className="w-4 h-4 text-sky-400 flex-shrink-0" />
                  <span className="font-mono text-gray-300 truncate">
                    {course.code}-C PROGRAMMING MOM-MS2-DEC.docx
                  </span>
                </div>
                <Download className="w-4 h-4 text-gray-400" />
              </div>
            </div>

            {/* Previous Committee Recommendations */}
            <div className="bg-[#18191e] border border-white/5 rounded-2xl p-4 space-y-2 text-xs">
              <div className="flex items-center gap-2 font-bold text-sm text-white">
                <AlertCircle className="w-4 h-4 text-purple-400" />
                <span>Previous Committee Recommendations</span>
              </div>
              <div className="p-3 bg-[#202229] rounded-xl text-gray-300 space-y-2 leading-relaxed">
                <p>1. All the assessments has to be submitted on time in WSTUDY compiler with automated evaluation.</p>
                <p>2. All the faculties are requested to adhere with the session plan and course file during class hours.</p>
              </div>
            </div>

            {/* Course Outcomes (CO) */}
            <div className="bg-[#18191e] border border-white/5 rounded-2xl p-4 space-y-3 text-xs">
              <div className="flex items-center gap-2 font-bold text-sm text-white">
                <Layers className="w-4 h-4 text-emerald-400" />
                <span>Course Outcomes</span>
              </div>
              <div className="space-y-2">
                {(course.outcomes || [
                  { code: 'CO1', desc: 'Construct structured C programs using constants, variables, data types, and preprocessor directives to address basic problems.' },
                  { code: 'CO2', desc: 'Examine and write solutions for problems using operators, decision-making, and looping constructs.' },
                  { code: 'CO3', desc: 'Solve problems for searching, sorting, and merging using array and string processing techniques.' },
                  { code: 'CO4', desc: 'Implement structures, unions, and nested structures for modeling and processing real-world data.' },
                  { code: 'CO5', desc: 'Design modular and scalable C programs using functions, recursion, pointers, and file handling.' }
                ]).map((co) => (
                  <div key={co.code} className="p-3 bg-[#202229] rounded-xl flex items-start gap-3">
                    <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold font-mono text-[11px] flex-shrink-0">
                      {co.code}
                    </span>
                    <p className="text-gray-300 leading-relaxed">{co.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* CO ➔ PO Mapping */}
            <div className="bg-[#18191e] border border-white/5 rounded-2xl p-4 space-y-2 text-xs">
              <div className="flex items-center gap-2 font-bold text-sm text-white">
                <span>CO ➔ PO Mapping</span>
              </div>
              <div className="text-[11px] text-gray-400 font-mono">
                B.Tech - Computer Science and Engineering · R2025
              </div>
              <div className="overflow-x-auto mt-2">
                <table className="w-full text-center border-collapse">
                  <thead>
                    <tr className="border-b border-white/10 text-gray-400 text-[11px]">
                      <th className="py-1 px-2 text-left">CO</th>
                      <th className="py-1 px-2">PO1</th>
                      <th className="py-1 px-2">PO2</th>
                      <th className="py-1 px-2">PO3</th>
                      <th className="py-1 px-2">PO4</th>
                      <th className="py-1 px-2">PO5</th>
                      <th className="py-1 px-2">PO6</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-gray-300 font-mono text-xs">
                    {(course.coPoMapping || [
                      { co: 'CO1', po: [3, 2, 2, '-', '-', 1] },
                      { co: 'CO2', po: [3, 3, 2, '-', '-', 1] },
                      { co: 'CO3', po: [3, 3, 3, 2, '-', 2] },
                      { co: 'CO4', po: [3, 3, 2, 2, '-', 2] },
                      { co: 'CO5', po: [3, 3, 3, 2, 2, 2] }
                    ]).map((row) => (
                      <tr key={row.co} className="hover:bg-white/5">
                        <td className="py-2 px-2 text-left font-bold text-indigo-400">{row.co}</td>
                        {row.po.map((val, idx) => (
                          <td key={idx} className="py-2 px-2">
                            {val !== '-' ? (
                              <span className="inline-block w-5 h-5 rounded bg-emerald-500/20 text-emerald-300 font-bold text-[11px] leading-5">
                                {val}
                              </span>
                            ) : (
                              <span className="text-gray-600">-</span>
                            )}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </motion.div>
        )}

        {/* Tab 2: Topics */}
        {activeTab === 'topics' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[#18191e] border border-white/5 rounded-2xl p-6 text-center text-xs text-gray-400"
          >
            <BookOpen className="w-8 h-8 text-gray-600 mx-auto mb-2" />
            <h4 className="font-bold text-white text-sm">Course Topics</h4>
            <p className="mt-1 text-gray-500">No content has been configured for this course yet.</p>
          </motion.div>
        )}

        {/* Tab 3: Sessions */}
        {activeTab === 'sessions' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-2.5 text-xs"
          >
            <div className="bg-[#18191e] border border-white/5 rounded-2xl p-4 flex justify-between items-center">
              <div>
                <div className="font-semibold text-white">Upcoming: Session 26</div>
                <div className="text-gray-400">File IO & Binary Files handling in C</div>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 text-[11px] font-semibold">
                Scheduled Nov 2
              </span>
            </div>
            <div className="bg-[#18191e] border border-white/5 rounded-2xl p-4 flex justify-between items-center">
              <div>
                <div className="font-semibold text-white">Session 25 (Completed)</div>
                <div className="text-gray-400">Pointers to Structures and Dynamic Memory</div>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-[11px] font-semibold">
                Completed
              </span>
            </div>
          </motion.div>
        )}

        {/* Tab 4: To Do */}
        {activeTab === 'todo' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-2.5 text-xs"
          >
            <div className="bg-[#18191e] border border-white/5 rounded-2xl p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <ListTodo className="w-5 h-5 text-amber-400" />
                <div>
                  <div className="font-bold text-white">Assignment 2: Pointer Arithmetic</div>
                  <div className="text-gray-400 text-[11px]">Due: Nov 5, 2026 · 100 Points</div>
                </div>
              </div>
              <button
                onClick={() => alert('Opening WSTUDY submission portal')}
                className="px-3 py-1 rounded-xl bg-amber-500 text-black font-bold text-xs cursor-pointer"
              >
                Submit
              </button>
            </div>
          </motion.div>
        )}

        {/* Tab 5: Attendance (matching video 00:15 - 00:19) */}
        {activeTab === 'attendance' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-3.5 text-xs"
          >
            {/* 4 Summary Stat Boxes */}
            <div className="grid grid-cols-4 gap-2">
              <div className="bg-[#18191e] border border-white/5 rounded-2xl p-3 text-center">
                <div className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">
                  TOTAL SESSIONS
                </div>
                <div className="text-xl font-extrabold text-white mt-1">
                  {totalSessions}
                </div>
              </div>
              <div className="bg-[#18191e] border border-white/5 rounded-2xl p-3 text-center">
                <div className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">
                  PRESENT
                </div>
                <div className="text-xl font-extrabold text-emerald-400 mt-1">
                  {presentCount}
                </div>
              </div>
              <div className="bg-[#18191e] border border-white/5 rounded-2xl p-3 text-center">
                <div className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">
                  ABSENT
                </div>
                <div className="text-xl font-extrabold text-rose-500 mt-1">
                  {absentCount}
                </div>
              </div>
              <div className="bg-[#18191e] border border-white/5 rounded-2xl p-3 text-center">
                <div className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">
                  ATTENDANCE %
                </div>
                <div className="text-xl font-extrabold text-[#3b82f6] mt-1 font-mono">
                  {attendancePct}%
                </div>
              </div>
            </div>

            {/* Attendance Logs Table */}
            <div className="bg-[#18191e] border border-white/5 rounded-2xl overflow-hidden">
              <div className="p-3 border-b border-white/5 grid grid-cols-4 text-[11px] font-bold text-gray-400 tracking-wider uppercase text-center">
                <div>S.NO</div>
                <div>DATE</div>
                <div>SESSION</div>
                <div>STATUS</div>
              </div>

              <div className="divide-y divide-white/5 max-h-[50vh] overflow-y-auto">
                {(course.attendanceLogs || []).map((log) => (
                  <div
                    key={log.sNo}
                    className="p-3 grid grid-cols-4 items-center text-center text-xs font-mono"
                  >
                    <div className="text-gray-400">{log.sNo}</div>
                    <div className="text-gray-300 font-sans text-[11px]">{log.date}</div>
                    <div className="text-gray-300">{log.session}</div>
                    <div>
                      {log.status === 'Present' ? (
                        <span className="inline-block px-3 py-0.5 rounded-md text-[11px] font-bold bg-emerald-950/70 text-emerald-400 border border-emerald-500/30">
                          Present
                        </span>
                      ) : (
                        <span className="inline-block px-3 py-0.5 rounded-md text-[11px] font-bold bg-rose-950/70 text-rose-400 border border-rose-500/30">
                          Absent
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};
