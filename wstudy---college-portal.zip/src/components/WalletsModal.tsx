import React, { useState } from 'react';
import { X, Wallet, ArrowUpRight, ArrowDownLeft, Plus, CreditCard, Sparkles } from 'lucide-react';
import { WalletTransaction } from '../types';

interface WalletsModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: WalletTransaction[];
  onTopUp: (amount: number) => void;
}

export const WalletsModal: React.FC<WalletsModalProps> = ({
  isOpen,
  onClose,
  transactions,
  onTopUp
}) => {
  const [balance, setBalance] = useState(1480);
  const [showTopUpOptions, setShowTopUpOptions] = useState(false);

  if (!isOpen) return null;

  const handleQuickAdd = (amt: number) => {
    setBalance((prev) => prev + amt);
    onTopUp(amt);
    setShowTopUpOptions(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#18191e] border border-white/10 rounded-3xl p-6 text-white shadow-2xl max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Wallet className="w-5 h-5 text-indigo-400" />
            <div>
              <h3 className="font-bold text-base">Campus Digital Wallet</h3>
              <p className="text-xs text-gray-400">SmartCard RFID & Mess Balance</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-4 space-y-4">
          {/* Main Card */}
          <div className="p-5 rounded-3xl bg-gradient-to-tr from-indigo-700 via-indigo-600 to-purple-600 text-white shadow-xl relative overflow-hidden">
            <div className="absolute right-[-20px] top-[-20px] w-36 h-36 bg-white/10 rounded-full blur-xl pointer-events-none" />
            
            <div className="flex justify-between items-start">
              <div>
                <span className="text-xs uppercase tracking-wider text-indigo-200">
                  Campus ID Balance
                </span>
                <div className="text-3xl font-extrabold mt-1">
                  ₹{balance.toLocaleString('en-IN')}
                </div>
              </div>
              <div className="px-2.5 py-1 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-bold">
                RFID ACTIVE
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between text-xs text-indigo-100 font-mono">
              <span>Card ID: **** 9092</span>
              <span>EXP: 06/28</span>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowTopUpOptions(!showTopUpOptions)}
              className="flex-1 py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4 text-emerald-400" />
              <span>Add Balance (UPI/Card)</span>
            </button>
          </div>

          {showTopUpOptions && (
            <div className="p-3 bg-[#202229] rounded-2xl border border-white/5 space-y-2 text-xs">
              <span className="text-gray-400 font-medium">Select recharge amount:</span>
              <div className="grid grid-cols-4 gap-2">
                {[100, 250, 500, 1000].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => handleQuickAdd(amt)}
                    className="py-2 rounded-xl bg-white/5 hover:bg-indigo-600 text-white font-bold transition-colors cursor-pointer"
                  >
                    +₹{amt}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Sub-wallets overview */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-3 rounded-2xl bg-[#202229] border border-white/5">
              <div className="text-gray-400">Mess Allowance</div>
              <div className="text-base font-bold text-white mt-1">₹420</div>
              <div className="text-[10px] text-gray-500">Canteen & Cafe</div>
            </div>
            <div className="p-3 rounded-2xl bg-[#202229] border border-white/5">
              <div className="text-gray-400">Print & Lab Tokens</div>
              <div className="text-base font-bold text-white mt-1">45 Sheets</div>
              <div className="text-[10px] text-gray-500">Library Station</div>
            </div>
          </div>

          {/* Recent transactions */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-gray-400 mb-2">
              Recent Transactions
            </h4>
            <div className="space-y-2">
              {transactions.map((tx) => (
                <div
                  key={tx.id}
                  className="p-3 rounded-2xl bg-[#202229] border border-white/5 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center ${
                        tx.type === 'Credit'
                          ? 'bg-emerald-500/15 text-emerald-400'
                          : 'bg-rose-500/15 text-rose-400'
                      }`}
                    >
                      {tx.type === 'Credit' ? (
                        <ArrowDownLeft className="w-4 h-4" />
                      ) : (
                        <ArrowUpRight className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <div className="font-medium text-white">{tx.title}</div>
                      <div className="text-[10px] text-gray-400 font-mono">{tx.date}</div>
                    </div>
                  </div>
                  <div
                    className={`font-mono font-bold ${
                      tx.type === 'Credit' ? 'text-emerald-400' : 'text-white'
                    }`}
                  >
                    {tx.type === 'Credit' ? '+' : '-'}₹{tx.amount}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-3 border-t border-white/10 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-medium text-white"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
