import React, { useState } from 'react';
import { X, Check, Image as ImageIcon, Sparkles } from 'lucide-react';
import { defaultWallpapers } from '../data/portalData';

interface WallpaperSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentWallpaperUrl: string;
  onSelectWallpaper: (url: string) => void;
}

export const WallpaperSelectorModal: React.FC<WallpaperSelectorModalProps> = ({
  isOpen,
  onClose,
  currentWallpaperUrl,
  onSelectWallpaper
}) => {
  const [customUrl, setCustomUrl] = useState('');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="w-full max-w-sm bg-[#18191e] border border-white/10 rounded-3xl p-5 text-white shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-sm">Dashboard Wallpaper</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-gray-400 mt-2 mb-4">
          Select a background theme for your WStudy dashboard:
        </p>

        {/* Wallpaper Presets */}
        <div className="grid grid-cols-2 gap-2.5">
          {defaultWallpapers.map((wp) => {
            const isSelected = currentWallpaperUrl === wp.url;
            return (
              <button
                key={wp.id}
                type="button"
                onClick={() => {
                  onSelectWallpaper(wp.url);
                  onClose();
                }}
                className={`relative h-24 rounded-2xl overflow-hidden border text-left transition-all group ${
                  isSelected
                    ? 'border-emerald-500 ring-2 ring-emerald-500/50'
                    : 'border-white/10 hover:border-white/30'
                }`}
              >
                {wp.url ? (
                  <img
                    src={wp.url}
                    alt={wp.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                ) : (
                  <div className="w-full h-full bg-[#0d0e12]" />
                )}

                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent p-2 flex flex-col justify-end">
                  <span className="text-[11px] font-semibold text-white leading-tight">
                    {wp.name}
                  </span>
                </div>

                {isSelected && (
                  <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-emerald-500 text-black flex items-center justify-center shadow">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Custom URL Input */}
        <div className="mt-4 pt-3 border-t border-white/10">
          <label className="text-[11px] text-gray-400 font-medium">Custom Image URL</label>
          <div className="mt-1 flex gap-2">
            <input
              type="url"
              placeholder="https://..."
              value={customUrl}
              onChange={(e) => setCustomUrl(e.target.value)}
              className="flex-1 bg-[#121316] border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400"
            />
            <button
              onClick={() => {
                if (customUrl.trim()) {
                  onSelectWallpaper(customUrl.trim());
                  onClose();
                }
              }}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white"
            >
              Apply
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
