import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Lock,
  User,
  Eye,
  EyeOff,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  KeyRound,
  CheckCircle2,
  GraduationCap
} from 'lucide-react';
import { StudentProfile } from '../types';

interface LoginPageProps {
  onLoginSuccess: (studentData?: Partial<StudentProfile>) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const [registerNo, setRegisterNo] = useState('211425104088');
  const [password, setPassword] = useState('••••••••••');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const sampleUsers = [
    {
      name: 'Aarav Sharma',
      regNo: '211425104088',
      dept: 'Computer Science and Engineering',
      degree: 'B.Tech',
      cgpa: 8.67,
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=400&h=400&q=80'
    },
    {
      name: 'Diya Patel',
      regNo: '211425104112',
      dept: 'Artificial Intelligence & Data Science',
      degree: 'B.Tech',
      cgpa: 9.15,
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&h=400&q=80'
    }
  ];

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!registerNo.trim()) {
      setErrorMsg('Please enter your Student Register Number');
      return;
    }
    setErrorMsg('');
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      const chosen = sampleUsers.find((u) => u.regNo === registerNo) || sampleUsers[0];
      onLoginSuccess({
        name: chosen.name,
        registerNumber: chosen.regNo,
        department: chosen.dept,
        degree: chosen.degree,
        cgpa: chosen.cgpa,
        avatarUrl: chosen.avatar
      });
    }, 800);
  };

  const handleSelectDemoUser = (user: typeof sampleUsers[0]) => {
    setRegisterNo(user.regNo);
    setPassword('student@2026');
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess({
        name: user.name,
        registerNumber: user.regNo,
        department: user.dept,
        degree: user.degree,
        cgpa: user.cgpa,
        avatarUrl: user.avatar
      });
    }, 600);
  };

  return (
    <div className="min-h-screen w-full relative flex items-center justify-center p-4 bg-[#0b0c10] text-white overflow-hidden">
      {/* Background wallpaper with dark vignette overlay */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-30 pointer-events-none"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1600&q=80")'
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-[#0b0c10] via-[#0b0c10]/90 to-transparent pointer-events-none" />

      {/* Floating ambient glow orbs */}
      <div className="absolute -top-24 -left-24 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-80 h-80 rounded-full bg-indigo-500/15 blur-3xl pointer-events-none" />

      {/* Main Login Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 220 }}
        className="relative z-10 w-full max-w-md bg-[#16171b]/95 backdrop-blur-2xl border border-white/10 rounded-[32px] p-6 sm:p-8 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)]"
      >
        {/* WSTUDY Crest Logo Header */}
        <div className="text-center">
          <div className="inline-flex relative mb-3">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 via-orange-500 to-indigo-600 p-[2.5px] shadow-[0_0_25px_rgba(245,158,11,0.4)] animate-pulse-subtle">
              <div className="w-full h-full rounded-[14px] bg-[#16171b] flex items-center justify-center">
                <span className="font-extrabold text-2xl bg-gradient-to-r from-amber-400 to-orange-400 bg-clip-text text-transparent">
                  WS
                </span>
              </div>
            </div>
            <div className="absolute -bottom-1 -right-1 p-1 rounded-full bg-emerald-500 text-black shadow">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
          </div>

          <h1 className="text-2xl font-extrabold tracking-tight text-white">
            WSTUDY Portal
          </h1>
          <p className="mt-1 text-xs text-gray-400">
            Sign in to access courses, attendance & academics
          </p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleLogin} className="mt-6 space-y-4">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs">
              {errorMsg}
            </div>
          )}

          {/* Register Number */}
          <div>
            <label className="block text-xs font-semibold text-gray-300 mb-1.5">
              Register Number / Student ID
            </label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                required
                value={registerNo}
                onChange={(e) => setRegisterNo(e.target.value)}
                placeholder="e.g. 211425104088"
                className="w-full bg-[#1e2026] border border-white/10 rounded-2xl pl-10 pr-4 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all font-mono"
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-gray-300">
                Portal Password / PIN
              </label>
              <button
                type="button"
                onClick={() => alert('Password reset link sent to registered student mobile SMS')}
                className="text-[11px] text-amber-400 hover:text-amber-300 transition-colors"
              >
                Forgot PIN?
              </button>
            </div>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full bg-[#1e2026] border border-white/10 rounded-2xl pl-10 pr-10 py-3 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition-all font-mono"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Remember me */}
          <div className="flex items-center justify-between text-xs text-gray-400 pt-1">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="rounded border-white/20 bg-white/5 text-amber-500 focus:ring-0 cursor-pointer"
              />
              <span>Remember this device</span>
            </label>
            <span className="text-[11px] text-emerald-400 font-mono flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              SSO Active
            </span>
          </div>

          {/* Sign In Button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            disabled={isLoading}
            className="w-full mt-2 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-black font-extrabold text-sm shadow-[0_10px_25px_rgba(245,158,11,0.3)] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            {isLoading ? (
              <>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 0.8, ease: 'linear' }}
                  className="w-4 h-4 border-2 border-black border-t-transparent rounded-full"
                />
                <span>Authenticating with WSTUDY...</span>
              </>
            ) : (
              <>
                <span>Sign In to WSTUDY</span>
                <ArrowRight className="w-4 h-4 stroke-[3]" />
              </>
            )}
          </motion.button>
        </form>

        {/* One-Click Quick Demo User Selection */}
        <div className="mt-6 pt-5 border-t border-white/10 space-y-2.5">
          <div className="flex items-center justify-between text-[11px] font-semibold text-gray-400 uppercase tracking-wider">
            <span>Instant Demo Logins</span>
            <span className="text-[10px] text-amber-400 lowercase">click to auto-sign-in</span>
          </div>

          <div className="space-y-2">
            {sampleUsers.map((u) => (
              <button
                key={u.regNo}
                type="button"
                onClick={() => handleSelectDemoUser(u)}
                className="w-full p-2.5 rounded-2xl bg-[#1e2026] hover:bg-[#252830] border border-white/5 flex items-center justify-between transition-colors text-left group cursor-pointer"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <img
                    src={u.avatar}
                    alt={u.name}
                    className="w-8 h-8 rounded-full object-cover border border-white/20 flex-shrink-0"
                  />
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors truncate">
                      {u.name}
                    </div>
                    <div className="text-[10px] text-gray-400 font-mono truncate">
                      {u.regNo} · {u.dept}
                    </div>
                  </div>
                </div>

                <div className="text-right flex-shrink-0 pl-2">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 font-mono">
                    {u.cgpa}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Security Footer */}
        <div className="mt-5 text-center text-[10px] text-gray-500">
          WSTUDY Academic Enterprise System · Encrypted 256-bit SSL
        </div>
      </motion.div>
    </div>
  );
};
