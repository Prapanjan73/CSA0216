import React, { useState } from 'react';
import { X, BookOpen, Check, Plus, AlertCircle, Sparkles } from 'lucide-react';

interface CourseEnrollmentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CourseEnrollmentModal: React.FC<CourseEnrollmentModalProps> = ({
  isOpen,
  onClose
}) => {
  const [enrolledCodes, setEnrolledCodes] = useState<string[]>([
    'CSA0216',
    'BTA0105',
    'EEA0115',
    'UBA0603'
  ]);

  const availableCourses = [
    { code: 'CSA0216', name: 'Data Structures and Algorithms', slot: 'SLOT A', credits: 4, category: 'Program Core', faculty: 'Dr. Marcus Vance' },
    { code: 'BTA0105', name: 'Biology & Life Science for Engineers', slot: 'SLOT B', credits: 3, category: 'University Core', faculty: 'Dr. Elena Rostova' },
    { code: 'EEA0115', name: 'Basic Electrical and Electronics Engineering', slot: 'SLOT C', credits: 4, category: 'University Core', faculty: 'Prof. Julian Sterling' },
    { code: 'UBA0603', name: 'Universal Human Values and Professional Ethics', slot: 'SLOT D', credits: 2, category: 'Program Core', faculty: 'Dr. Sophia Martinez' },
    { code: 'CSA0302', name: 'Database Management Systems & SQL', slot: 'SLOT E', credits: 4, category: 'Program Core', faculty: 'Dr. Keith Reynolds' },
    { code: 'MAT0204', name: 'Discrete Mathematical Structures', slot: 'SLOT F', credits: 4, category: 'University Core', faculty: 'Dr. Evelyn Hayes' },
    { code: 'AI0101', name: 'Foundations of Artificial Intelligence', slot: 'SLOT G', credits: 3, category: 'Program Elective', faculty: 'Dr. Liam Thorne' }
  ];

  if (!isOpen) return null;

  const toggleEnroll = (code: string) => {
    if (enrolledCodes.includes(code)) {
      setEnrolledCodes(enrolledCodes.filter((c) => c !== code));
    } else {
      setEnrolledCodes([...enrolledCodes, code]);
    }
  };

  const totalCredits = availableCourses
    .filter((c) => enrolledCodes.includes(c.code))
    .reduce((acc, c) => acc + c.credits, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-[#18191e] border border-white/10 rounded-3xl p-6 text-white shadow-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-purple-400" />
            <div>
              <h3 className="font-bold text-base">Course Enrollment</h3>
              <p className="text-xs text-gray-400">MS2 Term · Flexible Credit System</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Credit Tracker Banner */}
        <div className="mt-4 p-3.5 bg-[#202229] rounded-2xl border border-white/5 flex items-center justify-between text-xs">
          <div>
            <div className="text-gray-400">Total Enrolled Credits</div>
            <div className="text-xl font-bold text-white mt-0.5">
              {totalCredits} <span className="text-xs text-gray-400 font-normal">/ 24 max limit</span>
            </div>
          </div>
          <div className="text-right">
            <span className="px-2.5 py-1 rounded-full bg-purple-500/20 text-purple-300 font-semibold font-mono">
              {enrolledCodes.length} Subjects Selected
            </span>
          </div>
        </div>

        {/* Course List */}
        <div className="flex-1 overflow-y-auto py-3 space-y-2.5">
          {availableCourses.map((c) => {
            const isEnrolled = enrolledCodes.includes(c.code);
            return (
              <div
                key={c.code}
                className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between text-xs ${
                  isEnrolled
                    ? 'bg-purple-950/20 border-purple-500/40 text-white'
                    : 'bg-[#202229] border-white/5 text-gray-300'
                }`}
              >
                <div className="space-y-1 max-w-[280px]">
                  <div className="flex items-center gap-2">
                    <span className="font-bold font-mono text-white">{c.code}</span>
                    <span className="px-1.5 py-0.2 rounded bg-white/10 text-[10px] text-gray-300 font-medium">
                      {c.slot}
                    </span>
                    <span className="text-[10px] text-gray-400">· {c.credits} Credits</span>
                  </div>
                  <div className="font-medium text-white">{c.name}</div>
                  <div className="text-[11px] text-gray-400">{c.faculty} · {c.category}</div>
                </div>

                <button
                  onClick={() => toggleEnroll(c.code)}
                  className={`px-3 py-1.5 rounded-xl font-semibold text-xs flex items-center gap-1 cursor-pointer transition-colors ${
                    isEnrolled
                      ? 'bg-purple-600 text-white hover:bg-purple-500'
                      : 'bg-white/10 hover:bg-white/20 text-white'
                  }`}
                >
                  {isEnrolled ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Enrolled</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add</span>
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 flex justify-between items-center text-xs">
          <span className="text-gray-400">Changes auto-sync with WStudy timetable</span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold cursor-pointer shadow-lg"
          >
            Confirm & Save
          </button>
        </div>
      </div>
    </div>
  );
};
