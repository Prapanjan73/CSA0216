/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence, type Variants } from 'motion/react';
import {
  StudentProfile,
  CourseSlot,
  PortalNotice,
  ViewTab
} from './types';
import {
  initialStudentProfile,
  courseSlotsData,
  timetableMonthData,
  portalNoticesList,
  defaultDueItems,
  defaultWalletTransactions,
  academicProgressList,
  academicTranscriptData,
  allMyCoursesList
} from './data/portalData';
import { LoginPage } from './components/LoginPage';
import { Header } from './components/Header';
import { AttendanceCard } from './components/AttendanceCard';
import { MoodCheckInModal } from './components/MoodCheckInModal';
import { NavigationDrawer } from './components/NavigationDrawer';
import { CourseDetailView } from './components/CourseDetailView';
import { AcademicTranscriptView } from './components/AcademicTranscriptView';
import { StudentProgressView } from './components/StudentProgressView';
import { NoticeBoardView } from './components/NoticeBoardView';
import { TimetableModal } from './components/TimetableModal';
import { ProfileDropdown } from './components/ProfileDropdown';
import { DueListModal } from './components/DueListModal';
import { WalletsModal } from './components/WalletsModal';
import { OnDutyModal } from './components/OnDutyModal';
import { CourseEnrollmentModal } from './components/CourseEnrollmentModal';
import { WSpaceModal } from './components/WSpaceModal';
import { HostelTransportModal } from './components/HostelTransportModal';
import { WallpaperSelectorModal } from './components/WallpaperSelectorModal';
import { CampusChatModal } from './components/CampusChatModal';
import {
  Calendar,
  Sparkles,
  Smartphone,
  Monitor,
  LogOut
} from 'lucide-react';

export default function App() {
  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const savedAuth = localStorage.getItem('wstudy_auth');
    return savedAuth !== null ? savedAuth === 'true' : true;
  });

  // Student Profile state
  const [student, setStudent] = useState<StudentProfile>(() => {
    const saved = localStorage.getItem('wstudy_student_profile');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.registerNumber === '211425104088' || parsed.registerNumber === '211425104112') {
          return parsed;
        }
      } catch (e) {}
    }
    return initialStudentProfile;
  });

  const [courses, setCourses] = useState<CourseSlot[]>(courseSlotsData);
  const [notices, setNotices] = useState<PortalNotice[]>(portalNoticesList);
  const [currentView, setCurrentView] = useState<ViewTab>('home');
  const [selectedSemester, setSelectedSemester] = useState('MS2 Sep-Dec 2026 (UG)');
  const [activeCourseDetail, setActiveCourseDetail] = useState<CourseSlot>(courseSlotsData[0]);

  // Modals & Sheets
  const [isMoodModalOpen, setIsMoodModalOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isTimetableModalOpen, setIsTimetableModalOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [isDueListOpen, setIsDueListOpen] = useState(false);
  const [isWalletsOpen, setIsWalletsOpen] = useState(false);
  const [isOnDutyModalOpen, setIsOnDutyModalOpen] = useState(false);
  const [odCourseCode, setOdCourseCode] = useState('');
  const [isCourseEnrollmentOpen, setIsCourseEnrollmentOpen] = useState(false);
  const [isWSpaceOpen, setIsWSpaceOpen] = useState(false);
  const [isHostelTransportOpen, setIsHostelTransportOpen] = useState(false);
  const [hostelTransportType, setHostelTransportType] = useState<'transport' | 'hostel'>('transport');
  const [isWallpaperModalOpen, setIsWallpaperModalOpen] = useState(false);
  const [isCampusChatOpen, setIsCampusChatOpen] = useState(false);

  // Wallpaper & Theme state
  const [currentWallpaper, setCurrentWallpaper] = useState<string>(
    'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1600&q=80'
  );
  const [currentTheme, setCurrentTheme] = useState('Dark');

  // Device view mode: Phone simulator or wide desktop
  const [isMobileFrame, setIsMobileFrame] = useState(false);


  // Save profile changes
  const handleUpdateStudent = (updated: Partial<StudentProfile>) => {
    const next = { ...student, ...updated };
    setStudent(next);
    localStorage.setItem('wstudy_student_profile', JSON.stringify(next));
  };

  const handleLoginSuccess = (userData?: Partial<StudentProfile>) => {
    if (userData) {
      handleUpdateStudent(userData);
    }
    setIsAuthenticated(true);
    localStorage.setItem('wstudy_auth', 'true');
    setCurrentView('home');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.setItem('wstudy_auth', 'false');
    setIsProfileDropdownOpen(false);
  };

  // Handle Mood selection from Modal 1
  const handleMoodSelected = (rating: number) => {
    const happinessPct = rating * 20;
    handleUpdateStudent({ happiness: happinessPct });
  };

  // Bookmark toggle
  const handleToggleBookmark = (id: string) => {
    setNotices((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isBookmarked: !n.isBookmarked } : n))
    );
  };

  // Select course to view its full details page (as shown in video 00:07)
  const handleOpenCoursePage = (course: CourseSlot) => {
    setActiveCourseDetail(course);
    setCurrentView('courseDetail');
  };

  const handleOpenCourseByCode = (code: string) => {
    const found = courses.find((c) => c.code === code);
    if (found) {
      setActiveCourseDetail(found);
      setCurrentView('courseDetail');
    } else {
      const general = allMyCoursesList.find((c) => c.code === code);
      if (general) {
        setActiveCourseDetail({
          slot: general.slot,
          code: general.code,
          title: general.name,
          faculty: general.faculty,
          percentage: 85,
          color: '#22c55e',
          credits: 4,
          venue: 'Academic Hall',
          attendedClasses: 21,
          totalClasses: 25,
          category: 'Program Core',
          attendanceLogs: courseSlotsData[0].attendanceLogs
        });
        setCurrentView('courseDetail');
      }
    }
  };

  // Handle Profile Dropdown selections
  const handleSelectProfileOption = (option: string) => {
    setIsProfileDropdownOpen(false);
    switch (option) {
      case 'profile':
        setCurrentView('progress');
        break;
      case 'duelist':
        setIsDueListOpen(true);
        break;
      case 'wallets':
        setIsWalletsOpen(true);
        break;
      case 'credits':
        setCurrentView('progress');
        break;
      case 'theme':
        setCurrentTheme((prev) => (prev === 'Dark' ? 'OLED' : 'Dark'));
        break;
      case 'wallpaper':
        setIsWallpaperModalOpen(true);
        break;
      case 'widgets':
        alert('Widgets configuration: All attendance & schedule widgets active.');
        break;
      case 'logout':
        handleLogout();
        break;
      default:
        break;
    }
  };

  const handleHostelTransport = (type: 'transport' | 'hostel') => {
    setHostelTransportType(type);
    setIsHostelTransportOpen(true);
  };

  // If user is not logged in, render the Login Page!
  if (!isAuthenticated) {
    return (
      <LoginPage
        onLoginSuccess={handleLoginSuccess}
      />
    );
  }

  // Animation page transition variants for seamless screen transitions
  const pageMotionVariants: Variants = {
    initial: { opacity: 0, y: 16, scale: 0.985, filter: 'blur(4px)' },
    animate: {
      opacity: 1,
      y: 0,
      scale: 1,
      filter: 'blur(0px)',
      transition: { duration: 0.35, ease: 'easeOut' }
    },
    exit: {
      opacity: 0,
      y: -14,
      scale: 0.985,
      filter: 'blur(4px)',
      transition: { duration: 0.22, ease: 'easeIn' }
    }
  };

  // Screen Content rendering based on currentView
  const renderMainView = () => {
    if (currentView === 'progress') {
      return (
        <motion.div
          key="progress"
          variants={pageMotionVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          className="w-full"
        >
          <StudentProgressView
            student={student}
            academicProgress={academicProgressList}
            onBack={() => setCurrentView('home')}
            onUpdateSocialLinks={(links) => handleUpdateStudent({ socialLinks: links })}
            onOpenMoodCheckIn={() => setIsMoodModalOpen(true)}
          />
        </motion.div>
      );
    }

    if (currentView === 'notices') {
      return (
        <motion.div
          key="notices"
          variants={pageMotionVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          className="w-full"
        >
          <NoticeBoardView
            notices={notices}
            onBack={() => setCurrentView('home')}
            onToggleBookmark={handleToggleBookmark}
          />
        </motion.div>
      );
    }

    if (currentView === 'courseDetail') {
      return (
        <motion.div
          key="courseDetail"
          variants={pageMotionVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          className="w-full"
        >
          <CourseDetailView
            course={activeCourseDetail}
            onBack={() => setCurrentView('home')}
            onOpenTimetable={() => setIsTimetableModalOpen(true)}
          />
        </motion.div>
      );
    }

    if (currentView === 'transcript') {
      return (
        <motion.div
          key="transcript"
          variants={pageMotionVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          className="w-full"
        >
          <AcademicTranscriptView
            courses={academicTranscriptData}
            overallCgpa={student.cgpa}
            onBack={() => setCurrentView('home')}
          />
        </motion.div>
      );
    }

    // Default 'home' view matching video with enhanced animations & depth
    return (
      <motion.div
        key="home"
        variants={pageMotionVariants}
        initial="initial"
        animate="animate"
        exit="exit"
        className="relative min-h-[calc(100vh-60px)] flex flex-col justify-between p-4 sm:p-6 overflow-hidden w-full"
      >
        {/* Animated Background Wallpaper with slow breathing effect */}
        <div
          className="absolute inset-0 bg-cover bg-center transition-all duration-1000 pointer-events-none scale-105 animate-slow-breathe"
          style={{
            backgroundImage: currentWallpaper ? `url("${currentWallpaper}")` : 'none',
            backgroundColor: '#0c0e12'
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/45 via-transparent to-black/65 pointer-events-none" />
        </div>

        {/* Ambient atmospheric lighting orbs */}
        <div className="absolute top-1/4 -left-16 w-64 h-64 rounded-full bg-emerald-500/15 blur-3xl pointer-events-none animate-glow-pulse" />
        <div className="absolute top-1/3 -right-16 w-72 h-72 rounded-full bg-indigo-500/15 blur-3xl pointer-events-none animate-float" />


        {/* Floating Attendance Gauges Card on Top */}
        <div className="relative z-10 w-full pt-2 sm:pt-4">
          <AttendanceCard
            courseSlots={courses}
            selectedSemester={selectedSemester}
            onSemesterChange={setSelectedSemester}
            onSelectCourse={handleOpenCoursePage}
          />
        </div>

        {/* Quick actions dock at bottom of dashboard */}
        <div className="relative z-10 w-full max-w-sm mx-auto mt-8 mb-2">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="bg-black/60 backdrop-blur-xl border border-white/10 rounded-2xl p-2.5 flex items-center justify-around shadow-2xl text-xs"
          >
            <motion.button
              whileHover={{ scale: 1.1, y: -2 }}
              whileTap={{ scale: 0.92 }}
              onClick={() => setIsTimetableModalOpen(true)}
              className="flex flex-col items-center gap-1 text-gray-300 hover:text-white transition-colors cursor-pointer"
            >
              <Calendar className="w-4 h-4 text-amber-400" />
              <span className="text-[11px] font-medium">Timetable</span>
            </motion.button>

            <div className="w-[1px] h-6 bg-white/10" />

            <motion.button
              whileHover={{ scale: 1.1, y: -2 }}
              whileTap={{ scale: 0.92 }}
              onClick={() => setCurrentView('notices')}
              className="flex flex-col items-center gap-1 text-gray-300 hover:text-white transition-colors cursor-pointer"
            >
              <span className="relative">
                <span className="w-2 h-2 rounded-full bg-emerald-400 absolute -top-0.5 -right-0.5 animate-ping" />
                <span className="text-emerald-400 font-bold">📢</span>
              </span>
              <span className="text-[11px] font-medium">Notices</span>
            </motion.button>

            <div className="w-[1px] h-6 bg-white/10" />

            <motion.button
              whileHover={{ scale: 1.1, y: -2 }}
              whileTap={{ scale: 0.92 }}
              onClick={() => setCurrentView('progress')}
              className="flex flex-col items-center gap-1 text-gray-300 hover:text-white transition-colors cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-purple-400 animate-pulse" />
              <span className="text-[11px] font-medium">CGPA: {student.cgpa}</span>
            </motion.button>

            <div className="w-[1px] h-6 bg-white/10" />

            <motion.button
              whileHover={{ scale: 1.1, y: -2 }}
              whileTap={{ scale: 0.92 }}
              onClick={() => setIsMoodModalOpen(true)}
              className="flex flex-col items-center gap-1 text-gray-300 hover:text-white transition-colors cursor-pointer"
            >
              <span className="text-sm">😊</span>
              <span className="text-[11px] font-medium">Mood Check</span>
            </motion.button>
          </motion.div>
        </div>
      </motion.div>
    );
  };

  return (
    <div className="min-h-screen bg-[#0b0c10] text-[#e2e8f0] flex flex-col items-center justify-start transition-colors">
      {/* Top Banner on wide screens */}
      <div className="w-full bg-[#121316] border-b border-white/10 py-1.5 px-4 text-xs text-gray-400 hidden lg:flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            WSTUDY Campus Server Online
          </span>
          <span>·</span>
          <span>WSTUDY Engineering Academic Portal (Sep-Dec 2026)</span>
          <span>·</span>
          <span className="text-gray-300 font-medium">Logged in as {student.name} ({student.registerNumber})</span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsMobileFrame(!isMobileFrame)}
            className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-white transition-colors cursor-pointer font-medium"
          >
            {isMobileFrame ? (
              <>
                <Monitor className="w-3.5 h-3.5 text-amber-400" />
                <span>Switch to Full Browser Mode</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Switch to Phone Frame Mode (As in Video)</span>
              </>
            )}
          </button>
          <span>·</span>
          <button
            onClick={() => setIsMoodModalOpen(true)}
            className="text-gray-300 hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
          >
            <span>Daily Check-in</span>
          </button>
          <span>·</span>
          <button
            onClick={handleLogout}
            className="text-rose-400 hover:text-rose-300 transition-colors flex items-center gap-1 cursor-pointer"
            title="Log out and return to Login Screen"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Switch User / Logout</span>
          </button>
        </div>
      </div>

      {/* Main Container: Phone Frame or Responsive View */}
      <div
        className={`w-full transition-all duration-300 ${
          isMobileFrame
            ? 'max-w-[420px] my-4 sm:my-8 rounded-[44px] border-[8px] border-[#22242a] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] overflow-hidden bg-[#121316] relative'
            : 'max-w-2xl lg:max-w-4xl w-full min-h-screen bg-[#121316]'
        }`}
      >


        {/* Primary Header with WSTUDY Logo, Timetable, Bell, Chat, Avatar */}
        <div className="relative">
          <Header
            student={student}
            onOpenDrawer={() => setIsDrawerOpen(true)}
            onOpenTimetable={() => setIsTimetableModalOpen(true)}
            onOpenNotices={() => setCurrentView('notices')}
            onToggleProfileMenu={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
            unreadNoticesCount={notices.length}
            isMobileFrame={isMobileFrame}
            onToggleMobileFrame={() => setIsMobileFrame(!isMobileFrame)}
            onLogoClick={() => setCurrentView('home')}
            onOpenCommunityChat={() => setIsCampusChatOpen(true)}
          />

          {/* Profile Dropdown Popover */}
          <ProfileDropdown
            isOpen={isProfileDropdownOpen}
            onClose={() => setIsProfileDropdownOpen(false)}
            onSelectOption={handleSelectProfileOption}
            currentTheme={currentTheme}
          />
        </div>

        {/* Main Render Area */}
        <main className="relative flex-1">
          <AnimatePresence mode="wait">
            {renderMainView()}
          </AnimatePresence>
        </main>

        {/* Mobile Bottom Home Bar indicator */}
        {isMobileFrame && (
          <div className="w-full bg-[#121316] py-2 flex justify-center border-t border-white/5">
            <div className="w-32 h-1 rounded-full bg-white/30" />
          </div>
        )}
      </div>

      {/* Slide-out Left Navigation Drawer */}
      <NavigationDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        onNavigate={(tab) => {
          setCurrentView(tab);
          setIsDrawerOpen(false);
        }}
        onOpenWSpace={() => setIsWSpaceOpen(true)}
        onOpenODModal={() => {
          setOdCourseCode('');
          setIsOnDutyModalOpen(true);
        }}
        onOpenCourseEnrollment={() => setIsCourseEnrollmentOpen(true)}
        onOpenDualProgram={() => {
          alert('Dual Program Application: Applications for B.Tech + M.Tech Integrated Honors are open.');
        }}
        onOpenHostelTransport={handleHostelTransport}
        onSelectCourseByCode={handleOpenCourseByCode}
        student={student}
      />

      {/* Mood Check-In Modal */}
      <MoodCheckInModal
        isOpen={isMoodModalOpen}
        onClose={() => setIsMoodModalOpen(false)}
        studentName={student.name.split(' ').pop() || 'Aarav'}
        onMoodSelected={handleMoodSelected}
      />

      {/* My Timetable Modal with Week & Month views */}
      <TimetableModal
        isOpen={isTimetableModalOpen}
        onClose={() => setIsTimetableModalOpen(false)}
        timetableDays={timetableMonthData}
        onSelectCourse={(code) => {
          setIsTimetableModalOpen(false);
          handleOpenCourseByCode(code);
        }}
      />

      {/* Due List Modal */}
      <DueListModal
        isOpen={isDueListOpen}
        onClose={() => setIsDueListOpen(false)}
        items={defaultDueItems}
        onPayDue={(id) => {
          alert('Payment Successful! Transaction receipt generated.');
        }}
      />

      {/* Campus Wallets Modal */}
      <WalletsModal
        isOpen={isWalletsOpen}
        onClose={() => setIsWalletsOpen(false)}
        transactions={defaultWalletTransactions}
        onTopUp={(amt) => {
          alert(`Successfully recharged ₹${amt} to Campus SmartCard.`);
        }}
      />

      {/* On-Duty (OD) Application Modal */}
      <OnDutyModal
        isOpen={isOnDutyModalOpen}
        onClose={() => setIsOnDutyModalOpen(false)}
        defaultCourseCode={odCourseCode}
      />

      {/* Course Enrollment Modal */}
      <CourseEnrollmentModal
        isOpen={isCourseEnrollmentOpen}
        onClose={() => setIsCourseEnrollmentOpen(false)}
      />

      {/* WSpace Cloud Document Modal */}
      <WSpaceModal
        isOpen={isWSpaceOpen}
        onClose={() => setIsWSpaceOpen(false)}
      />

      {/* Hostel & Transport Modal */}
      <HostelTransportModal
        isOpen={isHostelTransportOpen}
        onClose={() => setIsHostelTransportOpen(false)}
        initialTab={hostelTransportType}
      />

      {/* Wallpaper Customizer Modal */}
      <WallpaperSelectorModal
        isOpen={isWallpaperModalOpen}
        onClose={() => setIsWallpaperModalOpen(false)}
        currentWallpaperUrl={currentWallpaper}
        onSelectWallpaper={(url) => setCurrentWallpaper(url)}
      />

      {/* Student Campus Chat Modal */}
      <CampusChatModal
        isOpen={isCampusChatOpen}
        onClose={() => setIsCampusChatOpen(false)}
        studentName={student.name}
      />
    </div>
  );
}
