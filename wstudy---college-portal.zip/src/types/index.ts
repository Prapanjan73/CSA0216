export type ViewTab = 
  | 'home' 
  | 'progress' 
  | 'notices' 
  | 'timetable' 
  | 'duelist' 
  | 'wallets' 
  | 'od' 
  | 'enrollment' 
  | 'wspace'
  | 'admissions'
  | 'courseDetail'
  | 'transcript';

export interface StudentProfile {
  name: string;
  registerNumber: string;
  degree: string;
  department: string;
  cgpa: number;
  creditsEarned: number;
  totalCredits: number;
  statusBadge: string;
  happiness: number;
  punctuality: number;
  assignmentsCount: number | string;
  missedTasks: number;
  avatarUrl: string;
  socialLinks: {
    github?: string;
    linkedin?: string;
    portfolio?: string;
    leetcode?: string;
  };
}

export interface AcademicCoreProgress {
  title: string;
  completed: number;
  total: number;
  cgpa: string;
  color: string;
}

export interface CourseAttendanceLog {
  sNo: number;
  date: string;
  session: number; // 1 or 2
  status: 'Present' | 'Absent' | 'OD Approved';
}

export interface CourseSlot {
  slot: string;
  code: string;
  title: string;
  percentage: number;
  color: string;
  credits: number;
  faculty: string;
  venue: string;
  attendedClasses: number;
  totalClasses: number;
  category: 'University Core' | 'Program Core' | 'Program Elective' | 'University Elective';
  goals?: string[];
  outcomes?: { code: string; desc: string }[];
  coPoMapping?: { co: string; po: (number | string)[] }[];
  attendanceLogs?: CourseAttendanceLog[];
}

export interface TranscriptCourse {
  code: string;
  name: string;
  credits: number;
  type: 'Program Core' | 'University Core' | 'Program Elective';
  status: 'Completed' | 'Failed Exam';
  grade: string;
}

export interface TimetableClass {
  code: string;
  slot: string;
  time: string;
  colorVariant: 'blue' | 'red' | 'green' | 'amber' | 'purple';
  venue?: string;
  faculty?: string;
  title?: string;
  startHour?: number;
  durationHours?: number;
}

export interface TimetableDay {
  dayName: string;
  dateNum: number;
  fullDate: string;
  classes: TimetableClass[];
}

export interface PortalNotice {
  id: string;
  title: string;
  category: 'INSTITUTION' | 'DEPARTMENT' | 'ACADEMIC' | 'EXAMINATION' | 'EVENTS';
  author: string;
  timestamp: string;
  audience: string;
  body: string;
  attachmentName?: string;
  attachmentUrl?: string;
  isBookmarked?: boolean;
}

export interface DueListItem {
  id: string;
  category: string;
  description: string;
  amount: number;
  dueDate: string;
  status: 'Pending' | 'Paid' | 'Overdue';
}

export interface WalletTransaction {
  id: string;
  type: 'Debit' | 'Credit';
  title: string;
  amount: number;
  date: string;
  wallet: 'Campus SmartCard' | 'Mess Wallet' | 'Print & Lab Credits';
}

export interface WSpaceFile {
  id: string;
  name: string;
  size: string;
  sizeBytes: number;
  uploadDate: string;
  category: 'Notes' | 'Assignments' | 'Lab Manuals' | 'Certificates';
}
